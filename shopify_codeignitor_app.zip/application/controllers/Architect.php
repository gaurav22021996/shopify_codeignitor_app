<?php
date_default_timezone_set('Asia/Kolkata');
class Architect extends CI_Controller{
	  public function __construct()
    {
        parent::__construct();
        $this->load->model('Global_model');
  		$this->load->library('form_validation');
        $this->load->library('session');
        $this->load->library('cart');
	
    }


    public function index()
    {
        $this->show_loginForm();
    }

    public function makeorder()
    {
        print_r($_POST);

    }

    public function Dashboard()
    { 
        $data=array();
        $architectId=$this->checkLogin();
        
       
        $this->load->Architect_template('dashboard',$data);
    }

    public function productDetails($productId=NULL)
    {   
        $data=array();
        $data['products']=$this->getProducts($productId);
        $this->load->Architect_template('productDetails',$data);
    }

    public function cart()
    {
        $data=array();
        $data['Cart']=getCart();
        $this->load->Architect_template('Cart',$data);
    }

    public function updateCartQty()
    {
        if($_POST['qty']!=0){
        $this->Global_model->updateQuantity($_POST['rowId'],$_POST['qty']);
        }
        else
        {
             $this->Global_model->remove_cart($_POST['rowId']);
        }
        echo '{"code":200}';
    }

    public function removeProduct()
    {
        $this->Global_model->remove_cart($_POST['rowId']);
         echo '{"code":200}';
    }

    public function Checkout()
    {

        $data=array();
        $data['Cart']=getCart();
        $this->load->Architect_template('checkout',$data);



    }



    public function addToCart()
    {
       // print_r($_POST);

        
        if(isset($_POST['selectedProduct']))
        {
           
           $architect_id=getSessionArchitect();
           $productId=$_POST['productid'];
           $productName=$_POST['productName'];
           $variantName= $_POST['variantName'];
           $selectedProduct= $_POST['selectedProduct'];
           $price= $_POST['price'];

           for($i=0; $i<= count($variantName); $i++)
           { 
                if(isset($selectedProduct[$i]))
                {   
                    $carttoadd['shopid']='';
                    $carttoadd['architect_id']=$architect_id;
                    $carttoadd['product_id']=$productId;
                    $carttoadd['product_name']= $productName;
                    $carttoadd['product_var_id']=$selectedProduct[$i];
                    $carttoadd['qty']=1;
                    $carttoadd['price']=$price[$i];
                    $carttoadd['product_option']=$variantName[$i];

                    $this->Global_model->cartAddUpdate($carttoadd);
                }


           }
           
   


          

          
        }

       $cartCount= getCartCount();
       echo '{"code":"200","cartCount":'.$cartCount.'}';
    }
    /*

     'shopid' => $data['shopid'],
            'architect_id'=>$data['architect_id'],
            'product_var_id'=>$data['product_var_id'],
            'product_id'=>$data['product_id'],
            'qty'=>$data['qty'],
            'price'=>$data['price'],
            'product_name'=>$data['product_name'],
            'product_option'=>$data['product_option']
    */
  // cartAddUpdate($data)



    public function productList($pageNo=NULL)
    {    
        $data['products']=NULL;
        $productCount=$this->getProductCount();
        if($productCount)
        {
            $pagen=$productCount/50;
            $totalPage= ceil($pagen);
            if($pageNo=='')
            {
                $pageNo=1;
            }

            if($pageNo < $totalPage)
            {
                $data['nextPage']=$pageNo+1;
            }
            else
            {
                 $data['nextPage']='';
            }

            if($pageNo >1 )
            {
                $data['previousPage']=$pageNo-1;
            }
            else
            {
                $data['previousPage']='';
            }
              if($totalPage>=$pageNo)
            {
               $data['products']= $this->getShopifyProduct($pageNo);
            }
            else
            {
                echo "invalid page";
            }

            
        }
        else
        {

        }

        $this->load->Architect_template('product_list',$data);
        
    }

    public function getShopifyProduct($page)
    {
        $accessData=getShop_accessToken_byShop('test-discount-app.myshopify.com');
          if($accessData['ACCESS_TOKEN']!='')
            {
                $this->load->library('Shopify' , $accessData);
                $datas=array(
                  "published_status"=>"unpublished"
              );

              $products=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products.json?published_status=unpublished', ],TRUE);
              return $products;
            }
          
         
    }

    public function getProducts($productId)
    {
         $accessData=getShop_accessToken_byShop('test-discount-app.myshopify.com');
          if($accessData['ACCESS_TOKEN']!='')
            {
                $this->load->library('Shopify' , $accessData);
               

              $products=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products/'.$productId.'.json'],TRUE);
              return $products;
            }
    }
    public function getProductCount()
    {
         $accessData=getShop_accessToken_byShop('test-discount-app.myshopify.com');
          if($accessData['ACCESS_TOKEN']!='')
            {
                $this->load->library('Shopify' , $accessData);
                $datas=array(
                  "published_status"=>"unpublished"
              );

              $productCount=$this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products/count.json?published_status=unpublished', ],TRUE);
                if(isset($productCount->count))
                {
                    return $productCount->count;
                }
                else
                {
                    return FALSE;

                }
            }
            else
            {
                return FALSE;

            }
          
           
    }



    public function show_loginForm()
    {
        $data=null;
        $this->load->view('Architect_template/login',$data);
      
    }
    public function login()
    {
        
        if($_POST['email']!='' && $_POST['password']!='')
        {
            $dataForm=$_POST;
            $loginData=$this->Global_model->login($dataForm);
            if($loginData)
            {
                
                if($loginData->_id!='')
                {
                    $new_session_data = array(
                    'architectId'  => $loginData->_id,
                    );

                    $this->session->set_userdata($new_session_data);
                   echo '{"code":200,"msg":"Success"}';
                }else
                {
                    echo '{"code":404,"msg":"Invalid Credentials."}';
                }
            }
            else
            {
                echo '{"code":404,"msg":"Invalid Credentials."}';
            }

        }
        else
        {
            if($_POST['email']=='')
            {
                echo '{"code":100,"msg":"Email Required."}';
            }
            else
            {
                echo '{"code":100,"msg":"Password Required."}';

            }

        }
    }

    public function signup()
    {
        //print_r($_POST);
        if($_POST['name']!='' && $_POST['email']!='' && $_POST['password']!='')
        {
            $formData=$_POST;
           $checkDuplicate= $this->Global_model->checkDuplicateEmail($formData);
           if($checkDuplicate)
           {
                $architectData=$this->Global_model->registerArchitect($formData);
                if($architectData)
                {
                    echo '{"code":200}';
                }
                else
                {
                     echo '{"code":100, "msg":"Something went wrong please try after some time"}';
                }
            }
            else
            {
                 echo '{"code":100, "msg":"Email id already registerd."}';
            }

        }
        else
        {
             echo '{"code":100,"msg":"All fields are required."}';
        }

    }

    public function show_signupForm()
    {
        $data=null;
         $this->load->view('Architect_template/signup',$data);
      
    }
    public function show_forgetPasswordForm()
    {
         $data=null;
         $this->load->view('Architect_template/forgetpassword',$data);
    }

    public function checkLogin()
    {
       $sessionData=$this->session->userdata('architectId');
       if(!$sessionData)
       {
            redirect('Architect/show_loginForm');
       }
       else
        {
            return $sessionData;
        }
      //architectId
    }
    public function checkLoginAjax()
    {
       return $sessionData=$this->session->userdata('architectId');
    }

    public function getLoggedArchitect()
    {
         $sessionData=$this->session->userdata('architectId');
    }



}