<?php
class Home extends CI_Controller{
	  public function __construct()
    {
        parent::__construct();
        $this->load->model('Global_model');
  		  $this->load->library('form_validation');
        $this->load->library('session');
        // if($this->session->userdata('access_token')=='')
        // {
        //   redirect('Auth/Install_login');
        // }
  	
    }

    public function addQuote()
    {
      if(isset($_POST['submit']))
      {
        $name= $this->input->post("name");
        $email = $this->input->post("email");
        $phone = $this->input->post("phone");
        $this->load->view('addQuoteSuccess');
      }
      else
      {
        $this->load->view('addQuote');
      }
    }


    public function importProduct()
    {
      $shop=$data['shop']=$_GET['shop'];
      $product_database=$this->getProduct();
      
      $oldproduct=$this->isAlready_exist($shop, $product_database->sku);
      if(count($oldproduct)>0)
      {
        

        $inventory_old= $oldproduct{0}->variants{0}->inventory_quantity;
        //print_r($oldproduct);
        $data['quantity']=$inventory_old+$product_database->inventory_quantity;
        $data['product_id']=$product_id_old= $oldproduct{0}->variants{0}->product_id;
        $data['variants_id']=$variantId_old= $oldproduct{0}->variants{0}->id;
        $this->upDateExistingProduct($shop,$data, $product_database);
        
      }
      else
      {
          $this->createProduct($shop, $product_database);
      }
    


    }

    public function upDateExistingProduct($shop,$updateData,$product_database)
    {
      
        $variants[]=array(
         'id'=>$updateData['variants_id'],
         'inventory_quantity'=>$updateData['quantity']
        );
      $productss=array(
        'product'=>array(
          'id'=>$updateData['product_id'],
          'variants'=>$variants
        ));

      $dataConfig= getShop_accessToken_byShop($shop);
      //echo  json_encode($productss);
      $this->load->library('Shopify' ,$dataConfig);
      //PUT /admin/products/#{product_id}.json
       $datashop=  $this->shopify->call(['METHOD' => 'PUT', 'URL' =>'/admin/products/'.$updateData['product_id'].'.json', 'DATA'=>$productss],TRUE);

                    if(isset($datashop->product))
                    {
                      if(count($datashop->product)>0){
                        $this->updateStatus($product_database);
                      }
                    }
    }

    public function isAlready_exist($shop, $sku)
    {
                    $dataConfig= getShop_accessToken_byShop($shop);
                    $this->load->library('Shopify' ,$dataConfig); 
                    $dataProduct=  $this->shopify->call(['METHOD' => 'GET', 'URL' =>'/admin/products.json?handle='.$sku],TRUE);
                    //echo '<pre>';
                    if(isset($dataProduct->products))
                    {
                      if(count($dataProduct->products)>0)
                      {
                        return $dataProduct->products;
                      }
                    }
                   
    }

    public function createProduct($shop, $productData)
    {
     
      
      
        $variants[]=array(
        'option1'=>$productData->options1_value,
        'option2'=>$productData->options2_value,
        'option3'=>$productData->options3_value,
        'price'=>$productData->price,
        'compare_at_price'=>$productData->compare_at_price,
        'sku'=>$productData->sku,
        'grams'=>$productData->grams,
        'inventory_management'=>$productData->inventory_management,
        'inventory_policy'=>$productData->inventory_policy,
        'inventory_quantity'=>$productData->inventory_quantity,
        'barcode'=>$productData->barcode,
        'fulfillment_service'=>$productData->fulfillment_service
        );
       
      $options1=array("name"=>$productData->options1_name, "values"=>array($productData->options1_value));
     $options2=array("name"=>$productData->options2_name, "values"=>array($productData->options2_value));
     $options3=array("name"=>$productData->options3_name, "values"=>array($productData->options3_value));

       $productss=array(
        'product'=>array(
          'title'=>$productData->title,
          'handle'=>$productData->sku,
          'vendor'=>$productData->vendor,
          'body_html'=>$productData->body_html,
          "options"=> array($options1, $options2, $options3),
          'variants'=>$variants,
        ));
      // echo  json_encode($productss);
         $dataConfig= getShop_accessToken_byShop($shop);
                    $this->load->library('Shopify' ,$dataConfig); 
                    $datashop=  $this->shopify->call(['METHOD' => 'POST', 'URL' =>'/admin/products.json', 'DATA'=>$productss],TRUE);
                    if(isset($datashop->product))
                    {
                      if(count($datashop->product)>0){
                        $this->updateStatus($productData);
                      }
                    }
                    

    }

    public function updateStatus($product)
    {
        $this->db->query("update tbl_filerombt set status=1 where sku='".$product->sku."'");
        echo '{"code":200}';
    }



    public function getProduct()
    {
      $query = $this->db->get_where('tbl_filerombt', array('status' => 0), 0, 1);
      $prdData=$query->row();
      return $prdData;
    }


    public function Dashboard()
    { 
      $shop=$data['shop']=$_GET['shop'];
      $this->load->load_admin('welcome',$data);

    }

    public function UpdateProduct()
    {   
        $shop=$data['shop']=$_GET['shop'];
        $this->load->load_admin('ListProduct',$data);
    }

    public function upload_csv()
    {
       //print_r($_FILES);
     if(!empty($_FILES['btcsv']['name']))
     {  
        if(!empty($_FILES["btcsv"]["type"]))
        {
            $fileName = $_FILES['btcsv']['name'];
            $valid_extensions = array("csv");
            $temporary = explode(".", $_FILES["btcsv"]["name"]);
              $sourcePath = $_FILES['btcsv']['tmp_name'];
               $targetPath = "uploads/".$fileName;
            if(move_uploaded_file($sourcePath,$targetPath))
            {   
                chmod($targetPath, 0777);
                $uploadedFile = $fileName;
            }

        }

     }

     if(!empty($_FILES['shopifycsv']['name']))
     {  
        if(!empty($_FILES["shopifycsv"]["type"]))
        {
            $fileName1 = $_FILES['shopifycsv']['name'];
            $valid_extensions1 = array("csv");
            $temporary1 = explode(".", $_FILES["shopifycsv"]["name"]);
              $sourcePath1 = $_FILES['shopifycsv']['tmp_name'];
               $targetPath1 = "uploads/".$fileName1;
            if(move_uploaded_file($sourcePath1,$targetPath1))
            {   
                chmod($targetPath1, 0777);
                $uploadedFile1 = $fileName1;
            }

        }

     }
   $file_path =  './uploads/'.$uploadedFile;
   $csv = array_map('str_getcsv', file($file_path));
   $i=0;
   $j=0;
   foreach ($csv as $value) 
   {

      if($i<1)
      {
         // print_r($value);
      }
      else
      { 
        if($i==1)
        {
          // print_r($value);
        }
          $insert=array(
          'handle' => $value[0],
          'title'=>$value[5],
          'body_html'=>$value[6],
          'vendor'=> $value[8], //'Buy wholesale '.$description.' wholesale tee',
          'product_type'=>$value[13],
          'tags'=>$value[3],
          'options1_name'=>"Format",
          'options1_value'=>$value[15],
          'options2_name'=>"Author",
          'options2_value'=>$value[7],
          'options3_name'=>"Genre",
          'options3_value'=>$value[25],
          'sku'=>$value[0],
          'grams'=>1,
          'inventory_management'=>"shopify",
          'inventory_quantity'=>$value[32],
          'inventory_policy'=>"deny",
          'fulfillment_service'=>"manual",
          'price'=> preg_replace("/[^0-9\.]/", "",$value[10]),
          'compare_at_price'=>preg_replace("/[^0-9\.]/", "",$value[11]),
          'requires_shipping'=>"", //number_format((float)$gtin_number,0,'',''),
          'taxable'=>"",
          'barcode'=>$value[0]
        //$this->explode_data($product_name)
      );

     $insertData[]=$insert;

      }

   $i++;
 }
 //echo "<pre>";
 $this->db->empty_table('tbl_filerombt');
 $this->insertData($insertData);
 }

 public function insertData($data)
 {
      if($this->db->insert_batch('tbl_filerombt',$data)){
          echo '{"code":200}';
      }
 }

    function createTable()
    {
      $handle = fopen("test.csv", "r");
      // Read first (headers) record only)
      $data = fgetcsv($handle, 1000, ",");
      $sql= 'CREATE TABLE table_name (';
      for($i=0;$i<count($data); $i++) {
      $sql .= $data[$i].' VARCHAR(50), ';
      }
      $sql .= ')';
      echo $sql;
      fclose($handle);

    }


        public function prdList()
        {   
         
      
        $sort = array( );
        $get['fields'] = array('*');
        if (isset($search))
          {
             $get['search'] = $search;
          }
        $get['myll']   = $_POST['start'];
        $get['offset'] = $_POST['length'];
        if (isset($_POST['order'][0]))
          {
            $orrd         = $_POST['order'][0];
            $get['title'] = $orrd['column'];
            $get['order'] = $orrd['dir'];
          }
          $get['table']='tbl_filerombt';
          $list= $this->Global_model->GetSingleDataRecord($get);
          //print_r($this->db->last_query());
        //print_r($list);
        $cc        = $list['count'];
        $data      = array();
        $no        = $_POST['start'];
        $total_rec = array_pop($list);
       // print_r($list);
       // exit;
        foreach ($list as $missing)
          {
            $no++;
            $row    = array();
            $row[]  = $missing->handle;
            $row[]  = $missing->title;
            $row[]  = $missing->body_html;
            $row[]  = $missing->vendor;
            $row[]  = $missing->product_type;
            $row[]  = $missing->tags;
            $row[]  = $missing->options1_name;
            $row[]  = $missing->options1_value;
            $row[]  = $missing->options2_name;
            $row[]  = $missing->options2_value;
            $row[]  = $missing->options3_name;
            $row[]  = $missing->options3_value;
            $row[]  = $missing->sku;
            $row[]  = $missing->grams;
            $row[]  = $missing->inventory_management;
            $row[]  = $missing->inventory_quantity;
            $row[]  = $missing->inventory_policy;
            $row[]  = $missing->fulfillment_service;
            $row[]  = $missing->price;
            $row[]  = $missing->compare_at_price;
            $row[]  = $missing->requires_shipping;
            $row[]  = $missing->taxable;
            $row[]  = $missing->barcode;
            $data[] = $row;
          }
        $output = array(
            "draw" => $_POST['draw'],
            "recordsTotal" => $cc,
            "recordsFiltered" => $total_rec,
            "data" => $data
        );
        echo json_encode($output);
    }


  
  function limit_words($string, $word_limit) {
  $string = strip_tags($string);
  $words = explode(' ', strip_tags($string));
  $return = trim(implode(' ', array_slice($words, 0, $word_limit)));
  if(strlen($return) < strlen($string)){
  $return .= '...';
  }
  return $return;
}
}