<?php
class MY_Loader extends CI_Loader {
    public function __construct()
{
    parent::__construct();

    // Initiate instance
    $this->ci =& get_instance();

    // Load model
    

}   


    public function Architect_template($template_name, $vars = array(), $return = FALSE)
    {
        $architectId=getSessionArchitect();
        $vars['architect']=getArchitectDetails($architectId);
        $vars['cartQty']=getCartCount();
        if($return):
            $content  = $this -> view('Architect_template/header', $vars, $return);
            $content .= $this -> view('Architect_template/'.$template_name, $vars, $return);
            $content .= $this -> view('Architect_template/footer', $vars, $return);

            return $content;

        else:
            $this -> view('Architect_template/header', $vars);
            $this -> view('Architect_template/'.$template_name, $vars);
            $this -> view('Architect_template/footer', $vars);

        endif;
    }
    public function load_template($template_name, $vars = array(), $return = FALSE)
    {
        if($return):
            $content  = $this -> view('templates/header', $vars, $return);
            $content .= $this -> view($template_name, $vars, $return);
            $content .= $this -> view('templates/footer', $vars, $return);

            return $content;

        else:
            $this -> view('templates/header', $vars);
            $this -> view($template_name, $vars);
            $this -> view('templates/footer', $vars);

        endif;
    }

    public function load_admin($template_name, $vars = array(), $return = FALSE)
    {

        if($return):
            $content  = $this -> view('templates/header_admin', $vars, $return);
            $content .= $this -> view($template_name, $vars, $return);
            $content .= $this -> view('templates/footer', $vars, $return);

            return $content;

        else:
            $this -> view('templates/header_admin', $vars);
            $this -> view($template_name, $vars);
            $this -> view('templates/footer', $vars);

        endif;
    }

    public function getArchitectPersonalDetails()
    {
          //$this->ci->load->model('Global_model');
         // $this->ci->load->library('session');
           //$data['architect']=  
    }


}
?>