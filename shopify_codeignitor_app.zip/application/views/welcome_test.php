
 <?php 
$primary_font = "Verdana";
$primary_font_color = "#000";
$primary_font_size = "12px";
$secondary_font = "Verdana";
$secondary_font_color = "#444";
$theme_color = "#303336";

?>
<style type="text/css">
  
    .btn-primary{
    background: -webkit-gradient(linear, left top, left bottom, from(#6371c7), to(#5563c1));
    background: linear-gradient(to bottom, #6371c7, #5563c1);
    border-color: #3f4eae;
    -webkit-box-shadow: inset 0 1px 0 0 #6f7bcb;
    box-shadow: inset 0 1px 0 0 #6f7bcb;
    color: #ffffff;
    border: 1px solid;
    padding: 8px 10px;
    border-radius: 6px;
  }
   #employee-grid {
    font-size: 12px;
  }
</style>

 <article class="">
 <div class="col-md-12">   
 <h3>Orders List</h3> 
 <h5 id="msgs"></h5>   
 <div class="col-md-3"> <input type="button" onclick="printMultipleOrder();" value="Print" name="print"></div>
 <div class="col-md-3"> <input type="button"  onclick="archiveMultipleOrder();" value="Archive" name="Archive"></div>            
<table id="employee-grid" class="table table-striped table-bordered table-hover" >
   <thead>
    <tr>
      <th><input type="checkbox" id="example-select-all" name="checkAll" class="singleCheck"></th>
      <th>Order </th>
      <th>Name </th>
      <th>Zip Code </th>
      <th>Total </th>
      <th>Tags</th>
      <th>Fraud</th>
      <!--<th>Fraud</th>
      <th>Paid</th>-->
      <!--<th>Card</th>-->
      <!--<th>Tracking Number</th>-->
      <th>Print</th>
      <th>Archive</th>
    </tr>
  </thead>
  <tbody>
  
    </tbody>
  </table> 
  </div>         
                 
 </article>              
<div>

<input type="hidden" name="">


</div>

  <div class="modal" id="modal-media">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content" style="padding:30px !important">
                           <div class="modal-header">
                        <button type="button" onclick="closeModal();" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title">Print details</h4>
                        </div>
                         <div class="c-l-md-12"><button class="btn printOut">Print</button></div>
                         <div id="print_sec">
<script type="text/javascript">
    $.get("https://fonts.googleapis.com/css?family={{ primary_font | replace: " ", "+" }}:300,400,700").done(function(response) {
        var pFontCss = response.replace(/ local\(.+?\)\,/g,"");
        var pStyle = document.createElement('style');
        var pHead = document.head || document.getElementsByTagName('head')[0];
        pStyle.type = 'text/css';
        pStyle.id = 'font-primary-33363';
        if (pStyle.styleSheet){
          pStyle.styleSheet.cssText = pFontCss;
        } else {
          pStyle.appendChild(document.createTextNode(pFontCss));
        }
        pHead.appendChild(pStyle);
      });
  <?php if ("Verdana" != '' && "Verdana" != "primary_font"){?>
    <script>
      $.get("https://fonts.googleapis.com/css?family={{ secondary_font | replace: " ", "+" }}:300,400,700").done(function(response) {
        var sFontCss = response.replace(/ local\(.+?\)\,/g,"");
        var sStyle = document.createElement('style');
        var sHead = document.head || document.getElementsByTagName('head')[0];
        sStyle.type = 'text/css';
        sStyle.id = 'font-secondary-33363';
        if (sStyle.styleSheet){
          sStyle.styleSheet.cssText = sFontCss;
        } else {
          sStyle.appendChild(document.createTextNode(sFontCss));
        }
        sHead.appendChild(sStyle);
      });
    </script>
   <?php } ?>
</script>
<script>
    $(function () {
         if (navigator.userAgent.indexOf('Safari') != -1 &&
         navigator.userAgent.indexOf('Chrome') == -1) {
             $("body").addClass("safari");
         }
       });
</script>

 <style type="text/css">
   .dataTables_filter input {
    width: 300px !important;
}
.ui-button--primary, .btn-primary, .domain-status__table-wrapper>div:first-child .ui-button {
    background: -webkit-gradient(linear, left top, left bottom, from(#6371c7), to(#5563c1));
    background: linear-gradient(to bottom, #6371c7, #5563c1);
    border-color: #3f4eae;
    -webkit-box-shadow: inset 0 1px 0 0 #6f7bcb;
    box-shadow: inset 0 1px 0 0 #6f7bcb;
    color: #ffffff;
  }
.modal-lg {
    max-width: 1000px !important;
}
 </style>
<style type="text/css">
    /* ### BASE - PAGE SIZING AND MARGIN SETUP NORMALIZATION ACROSS BROWSERS ### */
      @page {
        margin: 12mm !important;
        margin-top: 12mm !important;
        margin-right: 12mm !important;
        margin-bottom: 12mm !important;
        margin-left: 12mm !important;
      }
      @media print {
        .safari {
          padding-top: 15px;
          box-sizing: border-box;
        }
    /*    * {
          overflow: visible !important;
        }*/
        .printer-preview-content .printer-preview-content {
          padding-right: 10px;
          box-sizing: border-box;
        }
    /*    .printer-inline-preview .printer-preview-content .printer-preview-content {
          page-break-before: always;
        }
        .printer-inline-preview-first .printer-preview-content .printer-preview-content {
          page-break-before: avoid !important;
        }*/
      }
      @media screen {
        .printer-preview-content {
          padding: 16px 0;
          min-height: 800px;
          /* background-image: url(http://basehold.it/i/16) */
        }
        .printer-preview-content .printer-preview-content {
          margin-right: auto;
          margin-left: auto;
          max-width: 620px;
        }
      }
      @media screen,print {
    
        /* ### BASE - TYPOGRAPHY AND REMOVAL OF STANDARD SHOPIFY STYLING ### */
        .printer-preview-content .t33363 * {
          color:  #444;
          font-family: Verdana;
          font-size: 12px;
          font-weight: 400;
          line-height: 16px;
          text-rendering: optimizeLegibility;
          margin: 0 0 0 0;
          padding: 0 0 0 0;
          -webkit-print-color-adjust: exact;
          overflow: visible !important;
        }
        .printer-preview-content .t33363 h1 {
          font-size: 28px;
          line-height: 32px;
        }
        .printer-preview-content .t33363 h2 {
          font-size: 18px;
          line-height: 32px;
        }
        .printer-preview-content .t33363 h3 {
          font-size: 14px;
          line-height: 16px;
        }
        .printer-preview-content .t33363 h1,
        .printer-preview-content .t33363 h2,
        .printer-preview-content .t33363 h3 {
          margin-bottom: 16px;
        }
        .printer-preview-content .t33363 b,
        .printer-preview-content .t33363 b * {
          font-weight: bold;
        }
        .printer-preview-content .t33363 .text-right {
          text-align: right;
        }
        .printer-preview-content .t33363 .text-center {
          text-align: center;
        }
        .printer-preview-content .t33363 .no-wrap {
          white-space: nowrap;
        }
    
        /* ### BASE - GRID AND RE-USABLE LAYOUT COMPONENTS ### */
        .printer-preview-content .t33363 .row {
          width: 100%;
          display: block;
          clear: both;
        }
        .printer-preview-content .t33363 .row:after {
          content: "";
          display: table;
          clear: both;
        }
        .printer-preview-content .t33363 .col-xs-1,
        .printer-preview-content .t33363 .col-xs-2,
        .printer-preview-content .t33363 .col-xs-3,
        .printer-preview-content .t33363 .col-xs-4,
        .printer-preview-content .t33363 .col-xs-5,
        .printer-preview-content .t33363 .col-xs-6,
        .printer-preview-content .t33363 .col-xs-7,
        .printer-preview-content .t33363 .col-xs-8,
        .printer-preview-content .t33363 .col-xs-9,
        .printer-preview-content .t33363 .col-xs-10,
        .printer-preview-content .t33363 .col-xs-11,
        .printer-preview-content .t33363 .col-xs-12 {
          float: left;
          min-height: 1px;
          margin-bottom: 32px;
        }
        .printer-preview-content .t33363 .col-xs-12 {
          width: 100%;
        }
        .printer-preview-content .t33363 .col-xs-11 {
          width: 91.66666667%;
        }
        .printer-preview-content .t33363 .col-xs-10 {
          width: 83.33333333%;
        }
        .printer-preview-content .t33363 .col-xs-9 {
          width: 75%;
        }
        .printer-preview-content .t33363 .col-xs-8 {
          width: 66.66666667%;
        }
        .printer-preview-content .t33363 .col-xs-7 {
          width: 58.33333333%;
        }
        .printer-preview-content .t33363 .col-xs-6 {
          width: 50%;
        }
        .printer-preview-content .t33363 .col-xs-5 {
          width: 41.66666667%;
        }
        .printer-preview-content .t33363 .col-xs-4 {
          width: 33.33333333%;
        }
        .printer-preview-content .t33363 .col-xs-3 {
          width: 25%;
        }
        .printer-preview-content .t33363 .col-xs-2 {
          width: 16.66666667%;
        }
        .printer-preview-content .t33363 .col-xs-1 {
          width: 8.33333333%;
        }
        .printer-preview-content .t33363 .col-no-margin {
          margin-bottom: 0 !important;
        }
        .printer-preview-content .t33363 .clear-fix {
          clear: both;
        }
        .printer-preview-content .t33363 .half-margin-top {
          margin-top: 8px !important;
        }
        .printer-preview-content .t33363 .half-margin-bottom {
          margin-bottom: 8px !important;
        }
        .printer-preview-content .t33363 .margin-top {
          margin-top: 16px !important;
        }
        .printer-preview-content .t33363 .margin-bottom {
          margin-bottom: 16px !important;
        }
        .printer-preview-content .t33363 .double-margin-top {
          margin-top: 32px !important;
        }
        .printer-preview-content .t33363 .double-margin-bottom {
          margin-bottom: 32px !important;
        }
    
        /* ### BASE - TABLE STYLING ### */
        .printer-preview-content .t33363 table,
        .printer-preview-content .t33363 .table {
          width: 100%;
          max-width: 100%;
          background-color: transparent;
          border-collapse: collapse;
        }
        .printer-preview-content .t33363 table thead {
          display: table-row-group;
        }
        .printer-preview-content .t33363 table tbody tr {
          page-break-inside:avoid !important;
          page-break-after:auto !important;
        }
        .printer-preview-content .t33363 table tbody tr td {
          page-break-inside:avoid !important;
        }
        .printer-preview-content .t33363 th {
          white-space: nowrap;
          text-align: left;
          vertical-align: middle;
          border-top: 0;
          border-bottom: 0;
        }
        .printer-preview-content .t33363 td {
          vertical-align: middle;
          border-top: 0;
          border-bottom: 0;
        }
        .printer-preview-content .t33363 .order-table tbody > tr:nth-child(odd) td {
          background-color: #f9f9f9;
        }
        .printer-preview-content .t33363 .pricing-table tbody > tr:nth-child(even) > td {
          background-color: #f9f9f9;
        }
        .printer-preview-content .t33363 .pricing-table tbody > tr > td.pricing-table-title {
          word-break: break-all;
        }
        .printer-preview-content .t33363 th.order-table-qty {
          width: 10%;
        }
        .printer-preview-content .t33363 th.order-table-price {
          width: 10%;
        }
        .printer-preview-content .t33363 th.order-table-item-total,
        .printer-preview-content .t33363 th.order-table-reason {
          width: 12%;
        }
        .printer-preview-content .t33363 th.order-table-return-comments {
          width: 30%;
        }
        .printer-preview-content .t33363 .pricing-table-text {
          text-align: right;
          white-space: nowrap;
        }
    
        /* ### BASE - PRODUCT IMAGE SIZING TO RETAIN LINE HEIGHT RYTHM) ### */
        .printer-preview-content .t33363 .product-image-wrapper {
          width: 64px;
          max-height: 64px;
        }
        .printer-preview-content .t33363 .product-image {
          padding: 0 4px;
          page-break-inside:avoid !important;
          max-width: 64px;
        }
    
        /* ### BASE - LISTS RESET ### */
        .printer-preview-content .t33363 ul {
          list-style: none;
        }
        .printer-preview-content .t33363 li {
          color: #444;
          list-style: none;
        }
    
        /* ### BASE - LOGO ### */
        .printer-preview-content .t33363 .logo-wrapper {
          display: inline-block;
          width: 100%;
        }
        .printer-preview-content .t33363 .logo {
          float: left;
          padding-right: 15px;
          max-width: 100%;
          max-height: 108.0px;
        }
    
        /* ### BASE - BARCODE ### */
        .printer-preview-content .t33363 .order-number-barcode,
        .printer-preview-content .t33363 .product-barcode {
          display: block;
        }
    
        /* ### BASE - ADDITONAL COMMON SHARED TYPOGRAPHY AND ALIGNMENT ### */
        .printer-preview-content .t33363 .address {
          margin-right: 5%;
        }
        .printer-preview-content .t33363 .notes-title,
        .printer-preview-content .t33363 .return-codes {
          margin: 8px 0;
        }
        /* ### BASE - HORIZONTAL RULE MARKS ### */
        .printer-preview-content .t33363 hr {
          background: #303336;
          border-top: 0;
          border: 0;
          height: 2px;
          width: 100%;
          margin-bottom: -2px;
        }
    
      }

      @media print {
     .pagebr{page-break-after: always;}
}
</style>
<!-- Template Specific Styling -->
<style type="text/css">
    @media screen,print {
    
      /* ### DESIGN SPECIFIC - TYPOGRAPHY ### */
      .printer-preview-content .t33363 h1 {
        font-family: '{{ secondary_font }}';
        font-weight: bold;
        color: #303336;
      }
      .printer-preview-content .t33363 h2 {
        font-family: Verdana;
      }
      .printer-preview-content .t33363 h3 {
        font-family:Verdana;
        color: #303336;
      }
    
      /* ### DESIGN SPECIFIC - LOGO POSITIONING ### */
      .printer-preview-content .t33363 .logo {
        float: right;
        padding-right: 0;
        margin-bottom: 16px;
      }
    
      /* ### DESIGN SPECIFIC - STORE DETAILS ### */
      .printer-preview-content .t33363 .shop-block {
        text-align: center;
      }
      .printer-preview-content .t33363 .shop-block .shop-address-block b,
      .printer-preview-content .t33363 .shop-block .shop-address-block b * {
        color: #000;
      }
      .printer-preview-content .t33363 .shop-block .shop-domain {
        color: #303336;
      }
    
      .printer-preview-content .t33363 .shop-return-address b,
      .printer-preview-content .t33363 .shop-return-address b * {
        color:  #000;
      }
    
      /* ### DESIGN SPECIFIC - ORDER DETAILS ### */
      .printer-preview-content .t33363 .order-details-title {
        display: inline-block;
        font-weight: bold;
        color:  #000;
      }
    
      /* ### DESIGN SPECIFIC - BILL TO AND SHIP TO ADDRESS ### */
      .printer-preview-content .t33363 .address-title {
        font-weight: bold;
        color:  #000;
      }
    
      /* ### DESIGN SPECIFIC - TABLE HEADER ### */
      .printer-preview-content .t33363 .order-table thead tr th {
        padding-left: 4px;
        padding-right: 4px;
        border-top: 2px solid #303336;
        padding-top: 6px;
        border-bottom: 2px solid #d3d3d3;
        padding-bottom:6px;
        font-weight: bold;
        color: #303336;
      }
    
      /* ### DESIGN SPECIFIC - TABLE BODY (SHARED) ### */
      .printer-preview-content .t33363 .order-table tbody tr td,
      .printer-preview-content .t33363 .pricing-table tbody tr td {
        padding-left: 4px;
        padding-right: 4px;
        border-top: 0;
        padding-top: 8px;
        border-bottom: 1px solid #d3d3d3;
        padding-bottom:7px;
      }
      /* ### DESIGN SPECIFIC - ORDER TABLE SPECIFIC ### */
      .printer-preview-content .t33363 .order-table tbody > tr > td.line-item-description,
      .printer-preview-content .t33363 .order-table tbody > tr > td.line-item-qty {
        font-weight: bold;
        color: #000;
      }
      .printer-preview-content .t33363 .order-table tbody > tr > td.line-item-description p.line-item-sku {
        font-weight: normal;
      }
      /* ### DESIGN SPECIFIC - PRICING TABLE SPECIFIC ### */
      .printer-preview-content .t33363 .pricing-table tbody > tr.pricing-table-total-row > td {
        border-top: 2px solid #303336;
        border-bottom: 2px solid #303336;
        padding-bottom:6px;
      }
      .printer-preview-content .t33363 .pricing-table tbody > tr > td.pricing-table-title,
      .printer-preview-content .t33363 .pricing-table tbody > tr > td.pricing-table-title span {
        font-weight: bold;
        color: #000;
      }
      .printer-preview-content .t33363 .pricing-table tbody > tr.pricing-table-total-row .pricing-table-title,
      .printer-preview-content .t33363 .pricing-table tbody > tr.pricing-table-total-row .pricing-table-text {
        font-weight: bold;
        color: #000;
      }
    
      /* ### DESIGN SPECIFIC - ORDER NOTES ### */
      .printer-preview-content .t33363 .notes-title {
        font-weight: bold;
        color:#000;
      }
    
      /* ### DESIGN SPECIFIC - RETURN FORM REASON CODES ### */
      .printer-preview-content .t33363 .return-codes b,
      .printer-preview-content .t33363 .return-code b * {
        font-weight: bold;
        color: #000;
      }
    
      /* ### DESIGN SPECIFIC - THANK YOU MESSAGE ### */
      .printer-preview-content .t33363 .thanks-text {
        text-align: center;
        font-weight: bold;
        color: #303336;
      }
      .printer-preview-content .t33363 .thanks-text * {
        font-weight: bold;
        color: #303336;
      }
    
      /* ### DESIGN SPECIFIC - GIFT MESSAGE ### */
      .printer-preview-content .t33363 .gift-text {
        text-align: center;
        font-weight: bold;
        width: 80%;
        margin: 0 10%;
        padding-bottom:16px;
        font-size: 18px;
      }
      .printer-preview-content .t33363 .gift-text * {
        font-weight: bold;
        font-size: 18px;
      }
      .printer-preview-content .t33363 .gift-text svg {
        padding-bottom:8px;
      }
    
      /* ### DESIGN SPECIFIC - TERMS AND CONDITIONS ### */
      .printer-preview-content .t33363 .terms-text {
        font-size: 10px;
        text-align: center;
      }
      .printer-preview-content .t33363 .terms-text * {
        font-size: 10px;
      }
    
      /* ### DESIGN SPECIFIC - SOCIAL ICONS ### */
      .printer-preview-content .t33363 .social-icons {
        display: inline;
        width: 20px;
        margin: 8px 4px;
      }
    
    }


    .modal {
    max-height: 600px;
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 99999;
    display: none;
    overflow: scroll;
    outline: 0;
}
</style>
                         <div  id="modalContent">

                         </div>
                       </div>
                         <div class="c-l-md-12"><button class="btn printOut">Print</button></div>

                        </div>
                        <!-- /.modal-content -->
                    </div>
                    <!-- /.modal-dialog -->
                </div>

<script type="text/javascript">

  function closeModal()
  {
    $('#modalContent').html('');
     $('#modal-media').hide();
  }

function printMultipleOrder()
{
  var selectedcheck=getValueUsingClass();
  console.log(selectedcheck);
  if(selectedcheck.length > 0)
  {
    
  
    $.ajax(
            {
              type : 'POST',
              url : '<?php echo base_url(); ?>Testprint/printMultipleOrder',
              data : {shop:shop,access_token:access_token,orderId:selectedcheck},
              dataType:"json",
              beforeSend: function(data)
              {
              //  $('.loading').fadeIn();
              },
            success: function(data)
            { 

             //alert(data['billing_html']); 
                 $('#modal-media').show();
                 $('#modalContent').html(data['billing_html']);

          
        
            },async: false
        
        });
  }
}


function getValueUsingClass(){
  /* declare an checkbox array */
  var chkArray = [];
  
  /* look for all checkboes that have a class 'chk' attached to it and check if it was checked */
  $(".singleCheck:checked").each(function() {
    chkArray.push($(this).val());
  });
  
  /* we join the array separated by the comma */
  var selected;
  selected = chkArray.join(',') ;
  
  /* check if there is selected checkboxes, by default the length is 1 as it contains one single comma */
  if(selected.length > 0){
    return selected;
  }else{
    alert("Please at least one of the checkbox"); 
  }


}




function syncShopiFy_order(){
   /* $.ajax(
          {
              type : 'POST',
              url : '<?php echo base_url(); ?>Home/getOrders',
              data : {shop:shop,access_token:access_token,toalOrders:'<?php echo $orderCount; ?>'},
              dataType:"json",
            beforeSend: function(data)
            {
              //  $('.loading').fadeIn();
            },
           success: function(data)
           {  if(data['msg']!=''){
               $('#msgs').html(data['msg']);
              }
        
           },async: false
        
      });*/

}

function print_orders(orderId){
 $.ajax(
          {
              type : 'POST',
              url : '<?php echo base_url(); ?>Testprint/getOrders_details',
              data : {shop:shop,access_token:access_token,orderId:orderId},
              dataType:"json",
            beforeSend: function(data)
            {
              //  $('.loading').fadeIn();
            },
           success: function(data)
           { 

           //alert(data['billing_html']); 
            $('#modalContent').html(data['billing_html']);

           $('#modal-media').show();
        
           },async: false
        
      });
 //$('#modal-media').show();
}
  
 $(document).ready(function() {


 


table = $('#employee-grid').DataTable({
                "lengthMenu": [[10, 20], [10, 20]],
               // dom: 'lBfrtip',
                "serverSide": true, //Feature control DataTables' server-side processing mode.
                "ordering": false,
                "searching": false,
                 "order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
                "ajax": {
                        "url": '<?php echo base_url(); ?>Testprint/getOrders?shop='+shop+'&access_token='+access_token,
                        "type": "POST"
                },
               

        });

    } );

 function syncNewdata()
{
     table.ajax.reload();
}

 setInterval( syncNewdata, 30000);
 
 $(function(){
        $('.printOut').click(function(e){
            e.preventDefault();
            
           printHtml();
          // var printReport= document.getElementById('modalContent').innerHTML;
          // printJS('print_sec','html');
           // return false;
        });
    });

 function printHtml() {
var divToPrint = document.getElementById('print_sec');
           var popupWin = window.open('', '_blank', 'width=800,height=auto');
           popupWin.document.open();
           popupWin.document.write('<html><body onload="window.print()">' + divToPrint.innerHTML + '</html>');
            popupWin.document.close();
    }

 function printpage(){
    var originalContents = document.body.innerHTML;
    
    document.body.innerHTML = printReport;
    window.print();
    document.body.innerHTML = originalContents;
}

  // Handle click on "Select all" control
   $('#example-select-all').on('change', function(){
    var maincheck=$("#example-select-all:checked").length;
    console.log(maincheck);
   if(maincheck==1)
   {
      $(".case").prop('checked', $(this).prop("checked"));
   }
   else
   {
      $(".case").removeAttr("checked");
   }
     
   });

   function archiveMultipleOrder()
   {  
     // getValueUsingClassData();
       var selectedcheck=getValueUsingClassData();
  console.log(selectedcheck);
  if(selectedcheck.length > 0)
  {
    
  
    $.ajax(
            {
              type : 'POST',
              url : '<?php echo base_url(); ?>Testprint/archiveMultipleOrder',
              data : {shop:shop,access_token:access_token,orderId:selectedcheck},
              dataType:"json",
              beforeSend: function(data)
              {
              //  $('.loading').fadeIn();
              },
            success: function(data)
            { 

             table.ajax.reload();

          
        
            },async: false
        
        });
  }

   }

   function close_order(orderId)
   {
      $.ajax(
            {
              type : 'POST',
              url : '<?php echo base_url(); ?>Testprint/singleArchive',
              data : {shop:shop,access_token:access_token,orderId:orderId},
              dataType:"json",
              beforeSend: function(data)
              {
              //  $('.loading').fadeIn();
              },
            success: function(data)
            { 

             table.ajax.reload();

          
        
            },async: false
        
        });
   }


   function getValueUsingClassData(){
  /* declare an checkbox array */
  var chkArray = [];
  
  /* look for all checkboes that have a class 'chk' attached to it and check if it was checked */
  $(".singleCheck:checked").each(function() {
    chkArray.push($(this).attr('data-number'));
  });
  
  /* we join the array separated by the comma */
  var selected;
  selected = chkArray.join(',') ;
  
  /* check if there is selected checkboxes, by default the length is 1 as it contains one single comma */
  if(selected.length > 0){
    return selected;
  }else{
    alert("Please at least one of the checkbox"); 
  }


}

</script>