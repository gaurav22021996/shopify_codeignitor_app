<!DOCTYPE html>
<html>
<head>
<title>All Quotes</title>
<link rel="stylesheet" href="https://sdks.shopifycdn.com/polaris/latest/polaris.css" />
</head>
<body>

<div class="Polaris-Page">
  <div class="Polaris-Page__Header">
    <div class="Polaris-Page__Title">
      <div>
        <h1 class="Polaris-DisplayText Polaris-DisplayText--sizeLarge">All Quotes</h1>
      </div>
      <div></div>
    </div>
    <div class="Polaris-Page__Actions"></div>
  </div>
  <div class="Polaris-Page__Content">
    <div class="Polaris-Card">
      <div class="">
        <div class="Polaris-DataTable__Navigation"><button type="button" class="Polaris-Button Polaris-Button--disabled Polaris-Button--plain Polaris-Button--iconOnly" disabled="" aria-label="Scroll table left one column"><span class="Polaris-Button__Content"><span class="Polaris-Button__Icon"><span class="Polaris-Icon"><svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true"><path d="M12 16a.997.997 0 0 1-.707-.293l-5-5a.999.999 0 0 1 0-1.414l5-5a.999.999 0 1 1 1.414 1.414L8.414 10l4.293 4.293A.999.999 0 0 1 12 16" fill-rule="evenodd"></path></svg></span></span></span></button>
          <button
            type="button" class="Polaris-Button Polaris-Button--plain Polaris-Button--iconOnly" aria-label="Scroll table right one column"><span class="Polaris-Button__Content"><span class="Polaris-Button__Icon"><span class="Polaris-Icon"><svg class="Polaris-Icon__Svg" viewBox="0 0 20 20" focusable="false" aria-hidden="true"><path d="M8 16a.999.999 0 0 1-.707-1.707L11.586 10 7.293 5.707a.999.999 0 1 1 1.414-1.414l5 5a.999.999 0 0 1 0 1.414l-5 5A.997.997 0 0 1 8 16" fill-rule="evenodd"></path></svg></span></span>
            </span>
            </button>
        </div>
        <div class="Polaris-DataTable">
        	 <!-- class="Polaris-DataTable__ScrollContainer" -->
          <div>
            <table class="Polaris-DataTable__Table">
              <thead>
                <tr>
                  <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header" scope="col">Product</th>
                  <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header Polaris-DataTable__Cell--numeric" scope="col">Price</th>
                  <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header Polaris-DataTable__Cell--numeric" scope="col">SKU Number</th>
                  <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header Polaris-DataTable__Cell--numeric" scope="col">Net quantity</th>
                  <th class="Polaris-DataTable__Cell Polaris-DataTable__Cell--header Polaris-DataTable__Cell--numeric" scope="col">Net sales</th>
                </tr>
              </thead>
              <tbody>
                <tr class="Polaris-DataTable__TableRow">
                  <th class="Polaris-DataTable__Cell " scope="row">Emerald Silk Gown</th>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">$875.00</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">124689</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">140</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">$122,500.00</td>
                </tr>
                <tr class="Polaris-DataTable__TableRow">
                  <th class="Polaris-DataTable__Cell " scope="row">Mauve Cashmere Scarf</th>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">$230.00</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">124533</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">83</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">$19,090.00</td>
                </tr>
                <tr class="Polaris-DataTable__TableRow">
                  <th class="Polaris-DataTable__Cell " scope="row">Navy Merino Wool Blazer with khaki chinos and yellow belt</th>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">$445.00</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">124518</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">32</td>
                  <td class="Polaris-DataTable__Cell Polaris-DataTable__Cell--numeric">$14,240.00</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>