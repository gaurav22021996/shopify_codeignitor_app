
             
                <!-- /.modal -->
              
                <!-- /.modal -->
            </div>
        </div>
        <!-- Reference block for JS -->
        <div class="ref" id="ref">
            <div class="color-primary"></div>
            <div class="chart">
                <div class="color-primary"></div>
                <div class="color-secondary"></div>
            </div>
        </div>
        <script src="<?php echo base_url();?>theme_assets/js/vendor.js"></script>
        <script src="<?php echo base_url();?>theme_assets/js/app.js"></script>
        <script src="<?php echo base_url();?>theme_assets/jquery.js"></script>
        <script src="<?php echo base_url();?>theme_assets/jquery.dataTables.js"></script>
    </body>

</html>