 
 <form method="post" id="productForm" enctype="multipart/form-data">
   <div class="row" style="margin-top: 30px">
    <div class="col-md-3" style="margin-left: 30px">
       <label for="your-name">Upload Product  CSV</label>
  <input id="your-name" type="file" name="btcsv" accept=".csv,text/csv">
    </div>
     <div class="col-md-3">
       <label for="your-name">Upload Map CSV</label>
  <input id="your-name" type="file" name="shopifycsv" accept=".csv,text/csv">
    </div>
     <div class="col-md-3" style="padding-top: 30px">
       
  <button class="ui-button btn-primary"  type="submit" name="button">Upload</button>
    </div>
   </div>
</form>

<script type="text/javascript">
 /* var data = new FormData();
    $.each(files, function(key, value)
    {
        data.append(key, value);
    });
    */

 $(document).ready(function(){
    $( "#productForm" ).on('submit',function( e ) {
   e.preventDefault();
    var form = $('#productForm')[0];

    var data = new FormData(form);

    var Url = '<?php echo base_url(); ?>Home/upload_csv';
    $.ajax({
      type : 'POST',
      url : Url,
      cache       : false,
      contentType : false,
      processData : false,
      data : data,
      dataType:"json",
      beforeSend: function(data){
       
        },
      success: function(data){
       if(data['code']==200){
        window.location.href='<?php echo base_url(); ?>Home/UpdateProduct?shop=<?php echo $shop; ?>';
   
       }
       
      },async: false
    });
   });
   
   });


</script>