

<table id="employee-grid" class="table table-striped table-bordered table-hover" >
   <thead>
    <tr>
    <th>title</th>
    <th>body_html</th>
    <th>vendor</th>
    <th>product_type</th>
    <th>tags</th>
    <th>options1_name</th>
    <th>options1_value</th>
    <th>options2_name</th>
    <th>options2_value</th>
    <th>options3_name</th>
    <th>options3_value</th>
    <th>sku</th>
    <th>grams</th>
    <th>inventory_management</th>
    <th>inventory_quantity</th>
    <th>inventory_policy</th>
    <th>fulfillment_service</th>
    <th>price</th>
    <th>compare_at_price</th>
    <th>requires_shipping</th>
    <th>taxable</th>
    <th>barcode</th>

    </tr>

     <!--$row[]  = $missing->handle;
            $row[]  = $missing->title;
            $row[]  = $missing->body_html;
            $row[]  = $missing->vendor;
            $row[]  = $missing->product_type;
            $row[]  = $missing->tags;
            $row[]  = $missing->options1_name;
            $row[]  = $missing->options1_value;
            $row[]  = $missing->options2_name;
            $row[]  = $missing->options2_value;
            $row[]  = $missing->options3_name;
            $row[]  = $missing->options3_value;
            $row[]  = $missing->sku;
            $row[]  = $missing->grams;
            $row[]  = $missing->inventory_management;
            $row[]  = $missing->inventory_quantity;
            $row[]  = $missing->inventory_policy;
            $row[]  = $missing->fulfillment_service;
            $row[]  = $missing->price;
            $row[]  = $missing->compare_at_price;
            $row[]  = $missing->requires_shipping;
            $row[]  = $missing->taxable;
            $row[]  = $missing->barcode;-->
  </thead>
  <tbody>
  
    </tbody>
  </table> 
<script>
   $(document).ready(function() {

table = $('#employee-grid').DataTable({
                "lengthMenu": [[100, 500, 1000, 2000, 3000, -1], [100, 500, 1000, 2000, 3000, "All"]],
               // dom: 'lBfrtip',
                "serverSide": true, //Feature control DataTables' server-side processing mode.
                //"order": [], //Initial no order.
                // Load data for the table's content from an Ajax source
                ajax: {
                        "url": '<?php echo base_url(); ?>Home/prdList?shop=<?php echo $shop; ?>',
                        "type": "POST",
                        "data": function ( d ) {
                d.myKey = $('#customSort').val();
                // d.custom = $('#myInput').val();
                // etc
            }
                },


        });
/*$('#customSort').on('change',function(){
 table.ajax.reload();
})*/


    } );

 var Url = '<?php echo base_url(); ?>Home/importProduct?shop='+shop;
  var ImportProduct = function() {
    $.ajax({
      type : 'POST',
      url : Url,
      data : {shop:shop},
      dataType:"json",
      beforeSend: function(data){
       ShopifyApp.Bar.loadingOn(); 
        },
      success: function(data){
        if(data['code'] == 200)
        {
          console.log(data);
          ImportProduct();

        }
        else
        {   //ShopifyApp.flashError(data['msg']);
          

        }
      },
      error: function(){
        setTimeout(function(){
         //ImportProduct();
        }, 5000);
        
      },
      async: false
    });

  }
  ImportProduct();


</script>
</script>