

<form method="post" action="<?php echo base_url(); ?>Architect/Checkout" id="">
   <div id="body" class="clearfix" data-tg-refresh="body">
      <div class="" id="content">
         <div id="products-index" data-tg-refresh="products-index" class="page products-page has-contextual-help">
            <div class="ui-title-bar-container ui-title-bar-container--full-width">
               <div class="ui-title-bar">
                  <div class="ui-title-bar__main-group">
                     <div class="ui-title-bar__heading-group">
                        <span class="ui-title-bar__icon">
                           <svg class="next-icon next-icon--color-slate-lighter next-icon--size-20">
                              <use xlink:href="#next-products"></use>
                           </svg>
                        </span>
                        <h1 class="ui-title-bar__title">Cart Details</h1>
                     </div>
                  </div>
                  <!--<div class="ui-title-bar__actions-group">
                     <div class="ui-title-bar__actions"><a href="/admin/products/new" class="ui-button ui-button--primary ui-title-bar__action" data-bind-event-click="Shopify.AddProductFunnel.clickAddProduct()" data-allow-default="1">Add product</a></div>
                     </div>-->
               </div>
            </div>
            <div style="width: 80%;text-align: left; padding:20px">
               <h4></h4>
               <span>Products</span>
            </div>
            <div style="width: 100%;text-align: right; padding:20px">
             <span style="float: right; padding: 5px">
                  <p><?php echo form_submit('', 'Proceed to Checkout'); ?></p>
             </span>
             <span style="float: right; padding: 5px">
                
                <!-- <p><?php echo form_submit('', 'Update your Cart'); ?></p>-->
             </span>
            </div>
            <div class="ui-layout__item" id="product-outer-variants" data-tg-refresh="product-outer-variants">
               <section class="ui-card">
                  <?php //print_r($Cart); ?>
                  <?php echo form_open('path/to/controller/update/method'); ?>
                  <table cellpadding="6" cellspacing="1" style="width:100%" border="0">
                     <tr>
                        <th>Item Description</th>
                        <th>QTY</th>
                        <th style="text-align:right">Item Price</th>
                        <th style="text-align:right">Sub-Total</th>
                         <th style="text-align:right">Action</th>

                     </tr>
                     <?php $i = 1; 
                        $pricett=0;
                        ?>
                     <?php foreach ($Cart as $items): ?>
                     <tr>
                        <td>
                           <?php echo $items->product_name; ?>
                           <p>
                              <strong><?php echo $items->product_name;?>:</strong>
                              <?php echo $items->product_option; ?><br />
                           </p>
                        </td>
                        <td><?php echo form_input(array('name' => $i.'[qty]', 'onchange'=>'UpdateQty('.$items->_id.',this.value)', 'value' => $items->qty, 'maxlength' => '3', 'size' => '5')); ?></td>
                        <td style="text-align:right"><?php echo $items->price; ?></td>
                        <td style="text-align:right">$<?php echo $items->price*$items->qty;
                           $pricett=$pricett+$items->price*$items->qty ?></td>
                            <td style="text-align:right"><a onclick="RemoveCartProduct(<?php echo $items->_id; ?>);" href="#">Remove</a></td>
                     </tr>
                     <?php $i++; ?>
                     <?php endforeach; ?>
                     <tr>
                        <td colspan="2"> </td>
                        <td class="right"><strong>Total</strong></td>
                        <td class="right">$<?php echo $pricett; ?></td>
                     </tr>
                  </table>
               </section>
               <div style="width: 80%; text-align: left;padding:20px">
                  <span>
                   <!-- <p><?php echo form_submit('', 'Update your Cart'); ?></p>-->
                  </span>
               </div>
            </div>
         </div>
      </div>
   </div>
</form>
<script type="text/javascript">
   $(document).ready(function(){
    $( "#productForm" ).on('submit',function( e ) {
   e.preventDefault();
   var FormData = $('#productForm').serialize();
    var Url = '<?php echo base_url(); ?>Architect/addToCart';
    $.ajax({
      type : 'POST',
      url : Url,
      data : FormData,
      dataType:"json",
      beforeSend: function(data){
       
        },
      success: function(data){
       if(data['code']==200){
        $('.cart_qty').html('Cart ' + data['cartCount'])
   
       }
       
      },async: false
    });
   });
   
   });

   function UpdateQty(rowId,qty)
   {
      //alert(qty);
        var Url = '<?php echo base_url(); ?>Architect/updateCartQty';
        $.ajax({
      type : 'POST',
      url : Url,
      data : {rowId:rowId,qty:qty},
      dataType:"json",
      beforeSend: function(data){
       
        },
      success: function(data){
       if(data['code']==200){
       location.reload(); 
   
       }
       
      },async: false
    });

   }

   function RemoveCartProduct(rowId)
   {
      //alert(qty);
        var Url = '<?php echo base_url(); ?>Architect/removeProduct';
        $.ajax({
      type : 'POST',
      url : Url,
      data : {rowId:rowId},
      dataType:"json",
      beforeSend: function(data){
       
        },
      success: function(data){
       if(data['code']==200){
       location.reload(); 
   
       }
       
      },async: false
    });

   }
   
   /* $.ajax({
        type:'post',
        url:'store_items.php',
        data:{
          item_src:img_src,
          item_name:name,
          item_price:price
        },
        success:function(response) {
          document.getElementById("total_items").value=response;
        }
      });*/
   
</script>

