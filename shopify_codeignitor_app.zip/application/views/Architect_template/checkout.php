

<form method="post" action="<?php echo base_url(); ?>Architect/Checkout" id="">
   <div id="body" class="clearfix" data-tg-refresh="body">
      <div class="" id="content">
         <div id="products-index" data-tg-refresh="products-index" class="page products-page has-contextual-help">
            <div class="ui-title-bar-container ui-title-bar-container--full-width">
               <div class="ui-title-bar">
                  <div class="ui-title-bar__main-group">
                     <div class="ui-title-bar__heading-group">
                        <span class="ui-title-bar__icon">
                           <svg class="next-icon next-icon--color-slate-lighter next-icon--size-20">
                              <use xlink:href="#next-products"></use>
                           </svg>
                        </span>
                        <h1 class="ui-title-bar__title">Checkout</h1>
                     </div>
                  </div>
              
               </div>
            </div>
           

<div class="ui-layout__section ui-layout__section--primary">
   <div class="ui-layout__item">
      <div class="next-card relative">
         <section>
           
           
            <div class="next-card__section next-card__section--no-vertical-spacing" bind-show="draftBuilder.line_items.length">
               <table class="next-table--line-items">
                  <tbody id="line_item_rows" context="draftBuilder">
                        <?php $i = 1; 
                        $pricett=0;
                        ?>
                     <?php foreach ($Cart as $items): ?>
                     <tr>
                        <td class="next-table__cell--item-name" width="45%">
                           <a href="#"> <?php echo $items->product_name; ?></a>
                           <p class="type--subdued"><?php echo $items->product_option; ?></p>
                        </td>
                        <td class="type--left next-table__cell--grow-when-condensed" width="1">
                           <div class="ui-popover__container">
                              <button type="button" class="btn btn--link tooltip tooltip-top tooltip-center show-when-printing" bind-disabled="calculating">
                              <span><?php echo $items->price; ?></span>
                              </button>
                           </div>
                          
                        </td>
                        <td class="type--subdued">x</td>
                        <td style="min-width: 75px; width: 75px;">
                           <?php echo $items->qty; ?>
                        </td>
                        <td class="type--right">
                          <?php echo $items->price*$items->qty;
                           $pricett=$pricett+$items->price*$items->qty; ?>
                        </td>
                        
                     </tr>

                      <?php $i++; ?>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>



           
           
           
            <div class="next-card__section">
               <div class="wrappable" context="draftBuilder">
                  <div class="wrappable__item">
                     <div class="next-input-wrapper">
                        <label class="next-label" for="note">Notes</label>
                        <textarea expanding="true" placeholder="Add a note..." bind="note" bind-event-change="setNote()" id="note" class="ui-text-area ui-text-area--expanding" name="draft[note]" style="height: 34px;"></textarea>
                        <div class="only-when-printing"></div>
                     </div>
                  </div>
                  <div class="wrappable__item">
                     <div>
                        <table class="table--no-border">
                           <tbody>
                              <tr>
                                
                                 <td class="type--right">
                                    <span class="type--subdued">—</span>
                                 </td>
                              </tr>
                              <tr>
                                 <td class="type--right type--subdued">Subtotal</td>
                                 <td class="type--right"><?php echo $pricett; ?></td>
                              </tr>
                                <td class="type--right" style="width: 50%;">
                                    <strong>Total</strong>
                                 </td>
                                 <td class="type--right" style="width: 50%;">
                                    <strong><?php echo $pricett; ?></strong>
                                 </td>
                           </tbody>
                           
                           <tbody>
                              <tr>
                               
                                  <td class="type--right" colspan="2">
                                    <div class="ui-popover__container">
                                      <div style="text-align: left;">Customer Name: <input id="cname" type="text" name="name"></div>
                                      <div  style="text-align: left; margin-top: 30px">Customer Email: <input type="text" id="cemail" name="email"></div>
                                       <div style="text-align: right; margin-top: 30px">
                                        <button type="button" onclick="makeOrder()"> Submit</button>
                                       </div>
                                       
                                    </div>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     
                     </div>
                  </div>
               </div>
            </div>
         </section>

      
      </div>
   </div>
   
</div>


            
           
         </div>
      </div>
   </div>
</form>

   
<script type="text/javascript">
  function makeOrder()
  {
   var cname= $('#cname').val();
   var cemail= $('#cemail').val();
   var Url = '<?php echo base_url(); ?>Architect/makeorder';
    $.ajax({
      type : 'POST',
      url : Url,
      data : {cname:cname,cemail:cemail},
      dataType:"json",
      beforeSend: function(data){
       
        },
      success: function(data){
       if(data['code']==200){
        
   
       }
       
      },async: false
    });

  }

</script>

