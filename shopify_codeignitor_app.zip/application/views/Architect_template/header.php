<?php
//print_r($architect);
 ?>

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <link rel="dns-prefetch preconnect" href="https://cdn.shopify.com/">
      <link rel="dns-prefetch preconnect" href="https://www.gravatar.com/">
      <link rel="dns-prefetch preconnect" href="https://argus.shopifycloud.com/">
      <link rel="dns-prefetch preconnect" href="https://analytics.shopify.com/">
      <link rel="dns-prefetch preconnect" href="https://stats.g.doubleclick.net/">
      <link rel="dns-prefetch preconnect" href="https://www.google-analytics.com/">
      <link rel="dns-prefetch preconnect" href="https://connect.facebook.net/">
      <link rel="dns-prefetch preconnect" href="https://www.google.com/">
      <link rel="dns-prefetch preconnect" href="https://www.facebook.com/">
      <link rel="dns-prefetch preconnect" href="https://v.shopify.com/">
      <link rel="dns-prefetch preconnect" href="https://b.siftscience.com/">
      <meta charset="utf-8">
      <title>Architect</title>
      <meta name="apple-mobile-web-app-capable" content="yes">
      <meta name="apple-mobile-web-app-status-bar-style" content="black">
      <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/style-e9d9d2581905cd7b7304af47c082a05c52fd7e7b6c3dc85537a566.css" crossorigin="anonymous" data-turbolinks-track="admin-style-css" integrity="sha256-6dnSWBkFzXtzBK9HwIKgXFL9fntsPchVN6VmiuAiQSo=">
      <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/uptown/css/uptown.css">
      <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/uptown/custom.css">
      <script type="text/javascript" src="<?php echo base_url(); ?>theme_assets/jquery.js"></script>
   </head>
   <body class="page-home-index fresh-ui" id="body-content">
      <img alt="" role="presentation" class="helper--visually-hidden" src="test-discount-app%20~%20Home%20~%20Shopify_files/page.gif">
      <div class="ui-app-frame" data-tg-refresh="ui-app-frame" id="ui-app-frame">
         <header class="ui-app-frame__header">
            <div class="ui-top-bar">
               <div class="ui-top-bar__branding">
                  <a href="" style="color: #fff;font-size: 2rem;">
                  Architect
                  </a>
               </div>
               <div class="ui-top-bar__list">
                  <div class="ui-top-bar__item ui-top-bar__item--desktop-hidden">
                     <div class="ui-app-frame__aside-opener">
                        <button name="button" type="button" class="top-bar-button" aria-controls="AppFrameAside">
                           <svg class="next-icon next-icon--size-20 next-icon--no-nudge" role="img" aria-labelledby="menu-194db38c947e5b3316387551072cffa2-title">
                              <title id="menu-194db38c947e5b3316387551072cffa2-title">Open navigation</title>
                              <use xlink:href="#menu"></use>
                           </svg>
                        </button>
                     </div>
                  </div>
                  <div class="ui-top-bar__item ui-top-bar__item--fill">
                     <section class="top-bar-search">
                        <div class="top-bar-search__input-wrapper">
                           <div class="next-input-wrapper next-navigation-search">
                            
                           </div>
                           <span class="top-bar-search__clear-btn-wrapper">
                              <div class="ui-frame ui-frame--fill ui-frame--circle ui-frame--size-12">
                                 <svg class="next-icon next-icon--color-white next-icon--size-8 next-icon--no-nudge">
                                    <use xlink:href="#next-remove"></use>
                                 </svg>
                              </div>
                           </span>
                        </div>
                     </section>
                  </div>
                  <div class="ui-top-bar__item ui-top-bar__item--separated ui-top-bar__item--bleed ui-top-bar__item--mobile-hidden">
                     <div class="ui-popover__container ui-popover__container--full-width-container">
                      
                        <div name="button" type="button" class="top-bar-button top-bar-button--profile" id="AccountMenuActivator" data-tg-refresh="next-nav__avatar">
                           <div class="top-bar-profile">
                              <div class="top-bar-profile__avatar">
                                 <span class="user-avatar user-avatar--style-3">
                              
                                 
                                 </span>
                              </div>
                              <div class="top-bar-profile__summary">
                                 <p class="top-bar-profile__title">
                                    <?php echo $architect->name; ?>
                                 </p>
                                
                              </div>
                                 <a href="<?php echo base_url(); ?>Architect/cart"> <div class="cart_qty" style="padding-left: 10px;"> Cart   <?php echo $cartQty; ?></div></a>

                           </div>
                        </div>

                        <div class="ui-popover ui-popover--full-height ui-popover--reduced-spacing account_drop" data-popover-preferred-position="top">
                           <div class="ui-popover__tooltip"></div>
                           <div class="ui-popover__content-wrapper">
                              <div class="ui-popover__content">
                                 <div class="ui-popover__pane">
                                    <ul class="ui-action-list">
                                       <li class="ui-action-list__item">
                                          <a href="" class="ui-action-list-action" >
                                             <span class="ui-action-list-action__text">
                                                <div class="ui-stack ui-stack--wrap ui-stack--alignment-center ui-stack--spacing-tight">
                                                   <div class="ui-stack-item">
                                                      <svg role="img" class="next-icon next-icon--size-16" aria-labelledby="account-158ef6409196b6c05b2c07ef70689575-title">
                                                         <title id="account-158ef6409196b6c05b2c07ef70689575-title">Profile icon</title>
                                                         <use xlink:href="#account"></use>
                                                      </svg>
                                                   </div>
                                                   <div class="ui-stack-item ui-stack-item--fill">
                                                      <span>Your profile</span>
                                                   </div>
                                                </div>
                                             </span>
                                          </a>
                                       </li>
                                       <li class="ui-action-list__item">
                                          <a href="" class="ui-action-list-action" data-no-turbolink="true" data-method="post" data-shopify-desktop-id="admin-logout-link">
                                             <span class="ui-action-list-action__text">
                                                <div class="ui-stack ui-stack--wrap ui-stack--alignment-center ui-stack--spacing-tight">
                                                   <div class="ui-stack-item">
                                                      <svg role="img" class="next-icon next-icon--size-16" aria-labelledby="minor-log-out-e699f59f22ea83da1863285f46783d1c-title">
                                                         <title id="minor-log-out-e699f59f22ea83da1863285f46783d1c-title">Log out icon</title>
                                                         <use xlink:href="#minor-log-out"></use>
                                                      </svg>
                                                   </div>
                                                   <div class="ui-stack-item ui-stack-item--fill">
                                                      <span>Log out</span>
                                                   </div>
                                                </div>
                                             </span>
                                          </a>
                                       </li>
                                    </ul>
                                  
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </header>
         <aside id="AppFrameAside" class="ui-app-frame__aside">
            <div class="aside-profile">
               <div class="aside-profile__button" data-collapsible-target="AsideProfileMenu" aria-controls="AsideProfileMenu" aria-expanded="false" role="button">
                  <button name="button" type="button" class="top-bar-button top-bar-button--profile" id="AccountMenuActivator" data-tg-refresh="next-nav__avatar">
                     <div class="top-bar-profile">
                        <div class="top-bar-profile__avatar">
                           <span class="user-avatar user-avatar--style-3">
                           <span class="user-avatar__initials">
                           tA
                           </span>
                           <img alt="" class="gravatar gravatar--size-thumb" srcset="//proxy.shopifycdn.com/25b34294dc8cbbc06535f61fcba1698c93d6b7a29a80b6a72344e99535892f82/www.gravatar.com/avatar/09937581d7d44524d3f3e9febe6cd8b8.jpg?s=120&amp;d=blank 2x" src="test-discount-app%20~%20Home%20~%20Shopify_files/09937581d7d44524d3f3e9febe6cd8b8.png">
                           </span>
                        </div>
                        <div class="top-bar-profile__summary">
                           <p class="top-bar-profile__title">
                              test-discount-app Admin
                           </p>
                           <p class="top-bar-profile__description">
                              test-discount-app
                           </p>
                        </div>
                     </div>
                  </button>
                  <div class="aside-profile__icon">
                     <svg class="next-icon next-icon--rotate-90 next-icon--size-20 next-icon--no-nudge">
                        <use xlink:href="#next-chevron"></use>
                     </svg>
                  </div>
               </div>
               <div class="aside-profile__menu" id="AsideProfileMenu" data-collapsible="accordion" data-collapsible-state="collapsed" aria-hidden="true">
                  <ul class="ui-action-list">
                     <li class="ui-action-list__item">
                        <a href="https://test-discount-app.myshopify.com/admin/settings/account/7688388656" class="ui-action-list-action" data-bind-event-click="Shopify.Components.rootDispatcher.dispatch({type: 'nav:navigating'})" data-allow-default="1">
                           <span class="ui-action-list-action__text">
                              <div class="ui-stack ui-stack--wrap ui-stack--alignment-center ui-stack--spacing-tight">
                                 <div class="ui-stack-item">
                                    <svg role="img" class="next-icon next-icon--size-16" aria-labelledby="account-9d8e798a057297ef622da4bc47ae8872-title">
                                       <title id="account-9d8e798a057297ef622da4bc47ae8872-title">Profile icon</title>
                                       <use xlink:href="#account"></use>
                                    </svg>
                                 </div>
                                 <div class="ui-stack-item ui-stack-item--fill">
                                    <span>Your profile</span>
                                 </div>
                              </div>
                           </span>
                        </a>
                     </li>
                     <li class="ui-action-list__item">
                        <a href="https://test-discount-app.myshopify.com/admin/auth/logout" class="ui-action-list-action" data-no-turbolink="true" data-method="post" data-shopify-desktop-id="admin-logout-link">
                           <span class="ui-action-list-action__text">
                              <div class="ui-stack ui-stack--wrap ui-stack--alignment-center ui-stack--spacing-tight">
                                 <div class="ui-stack-item">
                                    <svg role="img" class="next-icon next-icon--size-16" aria-labelledby="minor-log-out-b315c2a9784d1b228ff4446bb94f4733-title">
                                       <title id="minor-log-out-b315c2a9784d1b228ff4446bb94f4733-title">Log out icon</title>
                                       <use xlink:href="#minor-log-out"></use>
                                    </svg>
                                 </div>
                                 <div class="ui-stack-item ui-stack-item--fill">
                                    <span>Log out</span>
                                 </div>
                              </div>
                           </span>
                        </a>
                     </li>
                  </ul>
                  <ul class="ui-action-list">
                     <li class="ui-action-list__item"><a href="https://help.shopify.com/" class="ui-action-list-action" data-track-click="{action: &quot;Help Center (Manual)&quot;, category: &quot;Need Help&quot;}" target="_blank" rel="noopener noreferrer"><span class="ui-action-list-action__text">Shopify Help Center</span></a></li>
                     <li class="ui-action-list__item"><a href="https://ecommerce.shopify.com/forums" class="ui-action-list-action" data-track-click="{action: &quot;Shopify Forums&quot;, category: &quot;Need Help&quot;}" target="_blank" rel="noopener noreferrer"><span class="ui-action-list-action__text">Community forums</span></a></li>
                     <li class="ui-action-list__item"><a href="https://partners.shopify.com/services_marketplace?shop=test-discount-app.myshopify.com&amp;utm_campaign=profile" class="ui-action-list-action"><span class="ui-action-list-action__text">Hire a Shopify Expert</span></a></li>
                     <li class="ui-action-list__item"><button class="ui-action-list-action" data-bind-event-click="keyboardShortcuts.show()" type="button" name="button"><span class="ui-action-list-action__text">Keyboard shortcuts</span></button></li>
                     <script data-define="{keyboardShortcuts: new Shopify.Modal(this, {&quot;size&quot;:&quot;large&quot;})}" type="text/html" class="modal_source">
                        <header>
                        <h2>Keyboard Shortcuts</h2>
                        <button class="btn btn--plain close-modal">×</button>
                        </header>
                        
                        <div class="keyboard-commands__container"
                        data-define="{ _init: Shopify.KeyboardShortcuts.buildModal(this) }">
                        <div class="next-grid">
                          <div class="next-grid__cell next-grid__cell--no-flex">
                            <h2 class="heading">General shortcuts</h2>
                            <ul class="keyboard-commands ssb js-general-shortcuts">
                              <li class="keyboard-command">
                                <kbd class="keyboard-key"></kbd>
                                <span class="keyboard-name"></span>
                              </li>
                            </ul>
                            <h2 class="heading">Adding items to your store</h2>
                            <ul class="keyboard-commands js-creation-shortcuts">
                              <li class="keyboard-command">
                                <kbd class="keyboard-key"></kbd>
                                <span class="keyboard-name"></span>
                              </li>
                            </ul>
                        </div>    <div class="next-grid__cell">
                            <h2 class="heading">Navigating your admin panel</h2>
                            <ul class="keyboard-commands js-navigation-shortcuts navigating-commands">
                              <li class="keyboard-command">
                                <kbd class="keyboard-key"></kbd>
                                <span class="keyboard-name"></span>
                              </li>
                            </ul>
                        </div></div></div>
                        
                     </script>
                  </ul>
               </div>
            </div>
            <div class="ui-scrollable aside-scrollable">
               <div class="ui-scrollable__track" style="visibility: hidden;">
                  <div class="ui-scrollable__scrollbar"></div>
               </div>
               <div class="ui-scrollable__scroll-content" style="padding: 0px 5px 5px 0px; margin: 0px -5px -5px 0px;">
                  <div class="ui-scrollable__content" style="margin-bottom: -5px;">
                     <div class="ui-scrollable__container">
                        <nav class="ui-nav ">
                           <div class="ui-nav__heading ui-nav__heading--hidden">
                              <div class="ui-nav__heading-label">
                                 <h3 class="ui-subheading ui-subheading--subdued" id="MainNavigationNavHeading">Main navigation</h3>
                              </div>
                           </div>
                           <ul class="ui-nav__group ui-nav__group--parent" aria-labelledby="MainNavigationNavHeading">
                              <li class="ui-nav__item ui-nav__item--parent ui-nav__item--selected ui-rollup__item--force-show">
                                 <a href="" class="ui-nav__link ui-nav__link--parent">
                                    <svg class="next-icon next-icon--size-20 next-icon--no-nudge">
                                       <use xlink:href="#next-dashboard"></use>
                                    </svg>
                                    <span class="ui-nav__label ui-nav__label--parent">Home</span>
                                 </a>
                              </li>
                              <li class="ui-nav__item ui-nav__item--parent">
                                 <a href="" class="ui-nav__link ui-nav__link--parent" data-rollup-target="Rollup1" aria-controls="Rollup1" aria-disabled="true" role="button">
                                    <svg class="next-icon next-icon--size-20 next-icon--no-nudge">
                                       <use xlink:href="#next-orders"></use>
                                    </svg>
                                    <span class="ui-nav__label ui-nav__label--parent">Orders</span><span class="ui-nav__badge">18</span>
                                 </a>
                                 <ul class="ui-rollup ui-nav__group ui-nav__group--child" data-rollup-mobile-only="true" id="Rollup1">
                                    <li class="ui-nav__item ui-nav__item--child"><a href="" class="ui-nav__link ui-nav__link--child"><span class="ui-nav__label ui-nav__label--child">All orders</span></a></li>
                                    <li class="ui-nav__item ui-nav__item--child"><a href="" class="ui-nav__link ui-nav__link--child"><span class="ui-nav__label ui-nav__label--child">Drafts</span></a></li>
                                   
                                 </ul>
                              </li>
                              <li class="ui-nav__item ui-nav__item--parent">
                                 <a href="" class="ui-nav__link ui-nav__link--parent" data-rollup-target="Rollup2" aria-controls="Rollup2" aria-disabled="true" role="button">
                                    <svg class="next-icon next-icon--size-20 next-icon--no-nudge">
                                       <use xlink:href="#next-products"></use>
                                    </svg>
                                    <span class="ui-nav__label ui-nav__label--parent">Products</span>
                                 </a>
                                 <ul class="ui-rollup ui-nav__group ui-nav__group--child" data-rollup-mobile-only="true" id="Rollup2">
                                    <li class="ui-nav__item ui-nav__item--child"><a href="" class="ui-nav__link ui-nav__link--child"><span class="ui-nav__label ui-nav__label--child">All products</span></a></li>
                                  
                                 </ul>
                              </li>
                              <li class="ui-nav__item ui-nav__item--parent">
                                 <a href="https://test-discount-app.myshopify.com/admin/customers" class="ui-nav__link ui-nav__link--parent">
                                    <svg class="next-icon next-icon--size-20 next-icon--no-nudge">
                                       <use xlink:href="#next-customers"></use>
                                    </svg>
                                    <span class="ui-nav__label ui-nav__label--parent">Customers</span>
                                 </a>
                              </li>
                             
                              <li class="ui-nav__item ui-nav__item--parent">
                                 <a href="https://test-discount-app.myshopify.com/admin/discounts" class="ui-nav__link ui-nav__link--parent">
                                    <svg class="next-icon next-icon--size-20 next-icon--no-nudge">
                                       <use xlink:href="#next-discounts"></use>
                                    </svg>
                                    <span class="ui-nav__label ui-nav__label--parent">Discounts</span>
                                 </a>
                              </li>
                            
                           </ul>
                          
                           <div class="ui-nav__align-bottom-shim"></div>
                           <ul class="ui-nav__group ui-nav__group--parent">
                              <li class="ui-nav__item ui-nav__item--parent">
                                 <a href="" class="ui-nav__link ui-nav__link--parent">
                                    <svg class="next-icon next-icon--size-20 next-icon--no-nudge">
                                       <use xlink:href="#next-settings"></use>
                                    </svg>
                                    <span class="ui-nav__label ui-nav__label--parent">Settings</span>
                                 </a>
                              </li>
                           </ul>
                        </nav>
                     </div>
                  </div>
               </div>
            </div>
            <div class="ui-app-frame__aside-closer">
               <button class="ui-button ui-button--transparent ui-button--icon-only" aria-controls="AppFrameAside" aria-label="Close navigation" type="button" name="button">
                  <svg class="next-icon next-icon--color-white next-icon--size-20">
                     <use xlink:href="#next-remove"></use>
                  </svg>
               </button>
            </div>
         </aside>
         <main id="AppFrameMain" class="ui-app-frame__main ">
            <div class="wrapper" data-define="{ notifier: new Shopify.Notifications({ shopName: Shopify.shop.settings.shopName, iconPath: &quot;\/\/cdn.shopify.com\/s\/assets\/admin\/shopify-notification-icon-5bb71743b535cc0810f4fa447c50934f8b99a46d030d55b8467c3831c14f5c36.png&quot; }) }" id="wrapper">


               