<!DOCTYPE html>
<html lang="en" class="fresh-html">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Architect</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">

     <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/uptown/css/uptown.css">
     <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/uptown/custom.css">
     <script type="text/javascript" src="<?php echo base_url(); ?>theme_assets/jquery.js"></script>
     <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
     <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
     
  </head>
  <body id="body-content" class="page fresh-ui">
 <main class="main-pane" role="main">
      <div class="main-container">

        <section class="ui-card">
          <div class="ui-card__section property-card-section" style="padding: 20px">

          <div class="ui-card__section main-card-section">
            <div class="ui-type-container">
            <h1 class="ui-title">Create your new Architect account</h1>


<form  class="new_account" id="new_account" action="" accept-charset="UTF-8" method="post">
  <div class="next-input-wrapper">
    <div class="next-input-wrapper">
      <label class="next-label" for="account_email">Email address</label>
      <input type="email" class="next-input" size="30" name="email" id="account_email">
      <p class="next-input__help-text">This email will be used to create your account</p>
    </div>
    
  </div>
  

  <div class="next-input-wrapper"><label class="next-label" for="account_first_name"> Name</label><input aria-required="true" aria-describedby="first-name-error" aria-invalid="false" class="next-input" size="30" type="text" name="name" id="account_first_name"></div>
  

  

  <div class="next-input-wrapper">
    <label class="next-label" for="account_password">Password</label>
    <div class="next-field__connected-wrapper ui-password"><input id="account_password" label="Password" name="password" autocomplete="off"  aria-invalid="false" class="ui-password__input next-input js-password-input " type="password" size="30">
  </div>
  </div>






  

  <button class="ui-button ui-button--primary ui-button--size-large" type="submit" name="commit">Create account</button>

  <p>
    Already have an account?
    <a href="<?php echo base_url(); ?>Architect/show_loginForm">Log in</a>
  </p>
  <p id="errormsg"></p>
</form>
</div>
</div>
</section>
      
      </div>
    </main>
</body>
</html>
<script type="text/javascript">
$('#new_account').submit(function(e) {
    e.preventDefault();
    $.ajax({
       type: "POST",
       url: '<?php echo base_url(); ?>Architect/signup',
       data: $(this).serialize(),
       dataType:'json',
       success: function(data)
       {
         if(data['code']==200)
         {
            window.location.href='<?php echo base_url(); ?>Architect/show_loginForm';
         }
         else
         {
            $('#errormsg').html(data['msg']);
         }
       }
   });
 });
</script>