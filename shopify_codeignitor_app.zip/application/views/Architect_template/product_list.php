<?php
//print_r($products);

 ?>

<div id="body" class="clearfix" data-tg-refresh="body">
   <div class="" id="content">
      <div id="products-index" data-tg-refresh="products-index" class="page products-page has-contextual-help">
         <div class="ui-title-bar-container ui-title-bar-container--full-width">
            <div class="ui-title-bar">
               <div class="ui-title-bar__main-group">
                  <div class="ui-title-bar__heading-group">
                     <span class="ui-title-bar__icon">
                        <svg class="next-icon next-icon--color-slate-lighter next-icon--size-20">
                           <use xlink:href="#next-products"></use>
                        </svg>
                     </span>
                     <h1 class="ui-title-bar__title">Products</h1>
                  </div>
               </div>
               <!--<div class="ui-title-bar__actions-group">
                  <div class="ui-title-bar__actions"><a href="/admin/products/new" class="ui-button ui-button--primary ui-title-bar__action" data-bind-event-click="Shopify.AddProductFunnel.clickAddProduct()" data-allow-default="1">Add product</a></div>
               </div>-->
            </div>
           
         </div>
        
      
         <div class="ui-layout ui-layout--full-width">
            <div class="ui-layout__sections">
               <div class="ui-layout__section">
                  <div class="ui-layout__item">
                     <section class="ui-card">
                        <div class="has-bulk-actions">
                           <div data-define="">
                              <div class="next-tab__container ">
                                 <ul class="next-tab__list" role="tablist" data-has-next-tab-controller="true">
                                    <li role="presentation"><a class="next-tab next-tab--is-active" tabindex="0" aria-controls="NextTabPanel-1-all" aria-selected="true" aria-label="All" href="">All</a></li>
                                    <li class="next-tab__list__disclosure-item dropdown-container">
                                       <span class="next-tab next-tab--disclosure" tabindex="-1" data-dropdown="~ .dropdown" aria-selected="true" aria-label="dropdown item" role="button" style="">
                                          <svg class="next-icon next-icon--size-16 next-icon--no-nudge">
                                             <use xlink:href="#next-ellipsis"></use>
                                          </svg>
                                       </span>
                                       <div class="dropdown">
                                          <ul class="next-tab__list--vertical" role="tablist"></ul>
                                       </div>
                                    </li>
                                 </ul>
                              </div>
                           
                           </div>
                           <div id="products-results" data-tg-refresh="products">
                              <div class="ui-card__section">
                                 <div class="ui-type-container">
                                    <div class="">
                                       <table id="all-products" class="table-hover expanded">
                                          <thead>
                                             <tr>
                                                <th class="select">
                                                  
                                                </th>
                                                <th class="image"></th>
                                                <th class="title is-sortable sorted-desc" data-bind-event-click="filterer.sort('title')">
                                                   <span>Product</span>
                                                </th>
                                                <th class="right inventory is-sortable " data-bind-event-click="filterer.sort('inventory_total')">
                                                   <span>Inventory</span>
                                                </th>
                                                <th class="product_type is-sortable " data-bind-event-click="filterer.sort('product_type')">
                                                   <span>Type</span>
                                                </th>
                                                <th class="vendor is-sortable " data-bind-event-click="filterer.sort('vendor')">
                                                   <span>Vendor</span>
                                                </th>
                                             </tr>
                                          </thead>

                                          <tbody data-context="bulkOperations">
                                            <?php if($products){ 
                                              foreach($products->products as $singleProduct){
                                                $quantity=0;
                                                foreach ($singleProduct->variants as $variants) {
                                                 $quantity=$quantity+$variants->inventory_quantity;
                                                }
                                              ?>
                                             <tr>
                                                <td class="select">
                                                   <div class="next-input-wrapper">
                                                      <label class="next-label helper--visually-hidden next-label--switch" for="product_ids_169381396528">Select product, Wren</label><input name="product_ids_169381396528" id="product_ids_169381396528" value="169381396528" data-bind="selected[169381396528]" data-bind-event-change="selectionChanged()" class="next-checkbox" type="checkbox">
                                                      <span class="next-checkbox--styled">
                                                         <svg class="next-icon next-icon--size-10 checkmark">
                                                            <use xlink:href="#next-checkmark-thick"></use>
                                                         </svg>
                                                      </span>
                                                   </div>
                                                </td>
                                                <td>
                                                   <a class="aspect-ratio aspect-ratio--square aspect-ratio--square--50 aspect-ratio--interactive" href="<?php echo base_url(); ?>Architect/productDetails/<?php echo $singleProduct->id; ?>">
                                                   <?php  if($singleProduct->image!=''){ ?>
                                                   <img title="Wren" class="aspect-ratio__content" src="<?php echo $singleProduct->image->src; ?>">
                                                  <?php } ?>
                                                   </a>                              
                                                </td>
                                                <td class="name">
                                                   <div class="ui-stack ui-stack--wrap">
                                                      <div class="ui-stack-item">
                                                         <a href="<?php echo base_url(); ?>Architect/productDetails/<?php echo $singleProduct->id; ?>" data-nested-link-target="true"><?php echo $singleProduct->title; ?></a>
                                                      </div>
                                                   </div>
                                                   <div></div>
                                                </td>
                                                <td class="total">
                                                   <p>
                                                      <span class="highlight-warning">
                                                      <?php echo  $quantity; ?>
                                                      </span>
                                                      in stock for <?php echo count($singleProduct->variants); ?> variant
                                                   </p>
                                                </td>
                                                <td class="type">
                                                   <p><?php echo $singleProduct->product_type; ?></p>
                                                </td>
                                                <td class="vendor">
                                                   <p><?php echo $singleProduct->vendor; ?></p>
                                                </td>
                                             </tr>
                                             <?php  } } ?>

                                             
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                              </div>
                              <div class="next-card__section">
                                 <div class="next-grid next-grid--no-padding next-grid--center-aligned">
                                    <div class="next-grid__cell next-grid__cell--no-flex">
                                       <ul id="pagination-links" class="segmented" refresh-always="">
                                        <?php if($previousPage!=''){?>
                                          <li>
                                             <a class="btn js-keep-open js-pagination-link js-prev-btn tooltip tooltip-bottom disabled"  href="<?php echo base_url(); ?>Architect/productList/<?php echo $previousPage; ?>">
                                                <span class="tooltip-container">
                                                <span class="tooltip-label">Previous (J)</span>
                                                </span>
                                                <svg role="img" class="next-icon next-icon--rotate-270 next-icon--size-16" aria-labelledby="next-arrow-detailed-0852c03e246ad9d2646b38f1675ea278-title">
                                                   <title id="next-arrow-detailed-0852c03e246ad9d2646b38f1675ea278-title">previous</title>
                                                   <use xlink:href="#next-arrow-detailed"></use>
                                                </svg>
                                             </a>
                                          </li>
                                          <?php } ?>
                                          <?php if($nextPage!=''){?>
                                          <li>
                                             <a class="btn js-keep-open js-pagination-link js-next-btn tooltip tooltip-bottom" track-click="" href="<?php echo base_url(); ?>Architect/productList/<?php echo $nextPage; ?>">
                                                <span class="tooltip-container">
                                                <span class="tooltip-label">Next (K)</span>
                                                </span>
                                                <svg role="img" class="next-icon next-icon--rotate-90 next-icon--size-16" aria-labelledby="next-arrow-detailed-3e778df8fa796a8e275c204735e64c5e-title">
                                                   <title id="next-arrow-detailed-3e778df8fa796a8e275c204735e64c5e-title">next</title>
                                                   <use xlink:href="#next-arrow-detailed"></use>
                                                </svg>
                                             </a>
                                          </li>
                                          <?php
                                          } 
                                          ?>
                                       </ul>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </section>
                  </div>
               </div>
            </div>
         </div>
         <div class="ui-footer-help">
            <div class="ui-footer-help__content">
               <div class="ui-footer-help__icon">
                  <svg class="next-icon next-icon--size-24 next-icon--no-nudge" role="img" aria-labelledby="next-help-circle-ad3ab9ebfd799f17872a8e000022e47f-title">
                     <title id="next-help-circle-ad3ab9ebfd799f17872a8e000022e47f-title">Help</title>
                     <use xlink:href="#next-help-circle"></use>
                  </svg>
               </div>
               <div>
                  <p>
                     Learn more about <a target="_blank" href="https://docs.shopify.com/manual/products">products</a>.
                  </p>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>

