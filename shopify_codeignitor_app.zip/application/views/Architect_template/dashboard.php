 <div id="body" class="clearfix" data-tg-refresh="body">
                  <div class="" id="content">
                     
                     <div data-define="{socialMarketingFrame: new Shopify.SocialMarketingFrame(this)}"></div>
                     <div data-modal-context-ref-for="SocialMarketingModal" data-define="{ SocialMarketingModal: new Shopify.UIModal(this.childNodes[0], { placeholder: this }) }"></div>
                     <div id="home-index" class="page page--with-sidebar page--with-greeting--default">
                        <header class="ui-title-bar-container">
                           <div class="ui-title-bar">
                              <div class="ui-title-bar__main-group">
                                 <div class="ui-title-bar__heading-group">
                                    <span class="ui-title-bar__icon">
                                       <svg class="next-icon next-icon--color-slate-lighter next-icon--size-20">
                                          <use xlink:href="#next-dashboard"></use>
                                       </svg>
                                    </span>
                                    <h1 class="ui-title-bar__title">Home</h1>
                                 </div>
                                 <div data-define="{titleBarActions: new Shopify.TitleBarActions(this)}" class="action-bar">
                                    <div class="ui-title-bar__mobile-primary-actions">
                                       <div class="ui-title-bar__actions">
                                          <div class="page__sidebar-toggle page__sidebar-toggle--show">
                                             <button class="ui-button" data-bind-event-click="Shopify.Home.toggleSidebar()" type="button" name="button">Summary</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="ui-title-bar__actions-group">
                                 <div class="ui-title-bar__actions">
                                    <div class="page__sidebar-toggle page__sidebar-toggle--show">
                                       <button class="ui-button" data-bind-event-click="Shopify.Home.toggleSidebar()" type="button" name="button">Summary</button>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="collapsible-header">
                              <div class="collapsible-header__heading"></div>
                           </div>
                        </header>
                        <div class="mobile-app-banner ui-dismissible--transitionable" data-define="{mobileBanner: new Shopify.DismissibleElement(this, 'mobile_app_banner', {permanent: true})}" data-bind-class="{'mobile-app-banner--is-enabled': Shopify.Browser.isMobile()}">
                           <button class="ui-button ui-button--transparent ui-button--icon-only ui-dismissible__action" data-bind-event-click="mobileBanner.dismiss()" type="button" name="button">
                              <svg class="next-icon next-icon--size-12">
                                 <use xlink:href="#next-remove"></use>
                              </svg>
                           </button>
                           <div class="mobile-app-banner__logo-container">
                              <img alt="Shopify Logo" class="mobile-app-banner__logo" src="test-discount-app%20~%20Home%20~%20Shopify_files/shopify-app-logo-fb28b5e698e86bb736999c5294d8b4f9a01f6ea9efe.png">
                           </div>
                           <div class="mobile-app-banner__content">
                              <p class="mobile-app-banner__heading">
                                 Shopify
                              </p>
                              <p class="mobile-app-banner__subheading">
                                 Official app
                              </p>
                           </div>
                           <a href="http://www.shopify.com/install/detect" class="ui-button" data-track-click="{category: &quot;Home&quot;, action: 'Banner', label: 'Mobile Shopify'}" target="_blank" rel="noopener noreferrer">Install</a>
                        </div>
                        <div class="modal-overlay" data-bind-event-click="Shopify.Home.toggleSidebar()"></div>
                        <header class="home-greeting">
                           <div class="home-takeover-greeting " >
                              <div class="home-takeover-greeting__wrapper no-live-ticker">
                                 <div class="ui-stack ui-stack--alignment-leading">
                                    <div class="ui-stack-item ui-stack-item--fill">
                                       <div class="fresh-home-greeting__content">
                                          <p class="fresh-home-greeting__heading">
                                             Good evening, Architect Name.
                                          </p>
                                          <p class="fresh-home-greeting__body">
                                             Here’s what’s happening with your store&nbsp;today.
                                          </p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="fresh-home-today-feature__toggle">
                                    <button class="ui-button" data-bind-event-click="Shopify.Home.toggleSidebar(this)" type="button" name="button">
                                       <svg class="next-icon next-icon--size-20 next-icon--inline-before">
                                          <use xlink:href="#report"></use>
                                       </svg>
                                       <span>View summary</span>
                                    </button>
                                 </div>
                                 <section class="home-takeover-stats">
                                    <div class="ui-stack ui-stack--wrap ui-stack--alignment-fill home-takeover-stats__wrapper">
                                       <div class="ui-stack-item ui-stack-item--fill home-takeover-stats__content">
                                          <div class="home-takeover-data">
                                             <div class="home-takeover-data__inner">
                                                <div class="sales-sparkline sparkline-wrapper hide"></div>
                                                <div class="home-takeover-data__wrap home-takeover-data__wrap--no-data">
                                                   <figure class="home-takeover-data__figure skeleton-today__heading skeleton-today__heading--hidden" data-bind-class="{
                                                      'skeleton-today__heading--hidden':
                                                      takeover.humanized.totalSales
                                                      }">
                                                      <svg class="next-icon next-icon--size-20 home-takeover-data__icon">
                                                         <use xlink:href="#cash"></use>
                                                      </svg>
                                                      <span class="home-takeover-data__number" data-bind="takeover.humanized.totalSales"> </span>
                                                   </figure>
                                                   <figcaption class="home-takeover-data__label">
                                                      <span class="valid-data">Today’s total sales</span>
                                                      <span class="no-data">No sales&nbsp;yet</span>
                                                   </figcaption>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="home-takeover-data">
                                             <div class="home-takeover-data__inner">
                                                <div class="orders-sparkline sparkline-wrapper hide"></div>
                                                <div class="home-takeover-data__wrap home-takeover-data__wrap--no-data">
                                                   <figure class="home-takeover-data__figure skeleton-today__heading skeleton-today__heading--hidden" data-bind-class="{
                                                      'skeleton-today__heading--hidden':
                                                      takeover.humanized.totalOrders
                                                      }">
                                                      <svg class="next-icon next-icon--size-20 home-takeover-data__icon">
                                                         <use xlink:href="#orders"></use>
                                                      </svg>
                                                      <span class="home-takeover-data__number" data-bind="takeover.humanized.totalOrders"> </span>
                                                   </figure>
                                                   <figcaption class="home-takeover-data__label">
                                                      <span class="valid-data">Today’s orders</span>
                                                      <span class="no-data">No orders&nbsp;yet</span>
                                                   </figcaption>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="home-takeover-data">
                                             <div class="home-takeover-data__inner">
                                                <div class="visits-sparkline sparkline-wrapper hide"></div>
                                                <div class="home-takeover-data__wrap">
                                                   <figure class="home-takeover-data__figure skeleton-today__heading skeleton-today__heading--hidden" data-bind-class="{
                                                      'skeleton-today__heading--hidden':
                                                      takeover.humanized.totalVisits
                                                      }">
                                                      <svg class="next-icon next-icon--size-20 home-takeover-data__icon">
                                                         <use xlink:href="#next-preview"></use>
                                                      </svg>
                                                      <span class="home-takeover-data__number" data-bind="takeover.humanized.totalVisits">2</span>
                                                   </figure>
                                                   <figcaption class="home-takeover-data__label">
                                                      <span class="valid-data">Today’s visits</span>
                                                      <span class="no-data">No visits&nbsp;yet</span>
                                                   </figcaption>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="home-takeover-live">
                                          <div class="home-takeover-live__data-wrapper">
                                             <figure class="home-takeover-live__data">
                                                <span class="home-takeover-live__number" data-bind="takeover.humanized.totalLiveVisits">0</span>
                                                <span class="home-takeover-live__badge">
                                                Live
                                                </span>
                                             </figure>
                                             <figcaption class="home-takeover-live__label type--subdued">
                                                Visitors right now
                                             </figcaption>
                                             <svg class="next-icon next-icon--color-slate-lighter next-icon--size-20 home-takeover-live__cta-icon">
                                                <use xlink:href="#next-chevron"></use>
                                             </svg>
                                             <a href="https://test-discount-app.myshopify.com/admin/dashboards/live" class="ui-button ui-button--outline ui-button--full-width ui-button--size-small home-takeover-live__cta">See Live View</a>
                                          </div>
                                       </div>
                                    </div>
                                 </section>
                              </div>
                           </div>
                        </header>
                        <div class="page__content">
                           <section class="ui-card ui-card__home-order-tasks">
                              <div class="home-order-tasks__content">
                                 <a class="ui_button--home-order-tasks-link" href="https://test-discount-app.myshopify.com/admin/orders?fulfillment_status=unfulfilled&amp;query=%28financial_status%3Apending+OR+financial_status%3Aauthorized+OR+financial_status%3Apaid+OR+financial_status%3Apartially_paid+OR+financial_status%3Apartially_refunded%29+AND+test%3Afalse&amp;status=open">
                                    <div class="home-order-tasks__item">
                                       <div class="ui-stack ui-stack--alignment-center ui-stack--spacing-none ui-stack--home-order-tasks-copy">
                                          <svg class="next-icon next-icon--color-slate-lightest next-icon--size-20 home-order-tasks__order-tasks-icon next-icon--no-nudge">
                                             <use xlink:href="#next-orders"></use>
                                          </svg>
                                          <div class="ui-stack-item ui-stack-item--fill">
                                             <strong>12 orders</strong> to fulfill
                                          </div>
                                       </div>
                                       <svg class="next-icon next-icon--color-sky-dark next-icon--size-20 home-order-tasks__order-tasks-chevron next-icon--no-nudge">
                                          <use xlink:href="#next-chevron"></use>
                                       </svg>
                                    </div>
                                 </a>
                                 <a class="ui_button--home-order-tasks-link" href="https://test-discount-app.myshopify.com/admin/orders?query=financial_status%3Apending+OR+financial_status%3Aauthorized&amp;status=open">
                                    <div class="home-order-tasks__item">
                                       <div class="ui-stack ui-stack--alignment-center ui-stack--spacing-none ui-stack--home-order-tasks-copy">
                                          <svg class="next-icon next-icon--color-slate-lightest next-icon--size-20 home-order-tasks__order-tasks-icon next-icon--no-nudge">
                                             <use xlink:href="#next-payments"></use>
                                          </svg>
                                          <div class="ui-stack-item ui-stack-item--fill">
                                             <strong>15 payments</strong> to capture
                                          </div>
                                       </div>
                                       <svg class="next-icon next-icon--color-sky-dark next-icon--size-20 home-order-tasks__order-tasks-chevron next-icon--no-nudge">
                                          <use xlink:href="#next-chevron"></use>
                                       </svg>
                                    </div>
                                 </a>
                              </div>
                           </section>
                          
                        </div>
                        <div class="page__sidebar">
                           <div class="page__sidebar-background"></div>
                           <div class="page__sidebar-content">
                              <div class="next-card next-card--stacked next-card--home-channel-filters" data-define="{homeSidebar: new Shopify.HomeSidebar(this, [{&quot;id&quot;:&quot;all&quot;,&quot;name&quot;:&quot;All channels&quot;},{&quot;id&quot;:&quot;580111&quot;,&quot;name&quot;:&quot;Online Store&quot;},{&quot;id&quot;:&quot;other&quot;,&quot;name&quot;:&quot;Other&quot;,&quot;additional_css&quot;:&quot;js-other-channel hide&quot;}], {
                                 showOther: true
                                 })}">
                                 <div class="fresh-home-sidebar-header">
                                    <div class="next-card__section next-card__section--half-spacing">
                                       <div class="ui-stack ui-stack--alignment-center ui-stack--spacing-tight">
                                          <div class="ui-stack-item ui-stack-item--fill">
                                             <h1 class="ui-title">Summary</h1>
                                          </div>
                                          <div class="ui-stack-item">
                                             <button class="ui-button ui-button--transparent" data-bind-event-click="Shopify.Home.toggleSidebar()" aria-label="Close summary" type="button" name="button">
                                                <svg class="next-icon next-icon--size-12">
                                                   <use xlink:href="#next-remove"></use>
                                                </svg>
                                             </button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="next-card__section">
                                    <div class="next-grid next-grid--no-outside-padding">
                                       <div class="next-grid__cell">
                                          <span class="ui-channel-selector" define="{channelpicker: new Shopify.SummaryReportChannelpicker(this, [{&quot;id&quot;:&quot;all&quot;,&quot;name&quot;:&quot;All channels&quot;},{&quot;id&quot;:&quot;580111&quot;,&quot;name&quot;:&quot;Online Store&quot;},{&quot;id&quot;:&quot;other&quot;,&quot;name&quot;:&quot;Other&quot;,&quot;additional_css&quot;:&quot;js-other-channel hide&quot;}])}" context="channelpicker">
                                             <span class="only-when-printing--inline" bind="currentChannelLabel">All channels</span>
                                             <span data-eval="setChannel(&quot;all&quot;)">
                                                <div class="ui-popover__container ui-popover__container--full-width-container">
                                                   <button class="ui-button ui-channel-selector__activator btn--full-width" type="button" name="button">
                                                      <div class="next-grid next-grid--no-padding next-grid--space-between">
                                                         <div class="next-grid__cell">
                                                            <div class="type--left type--truncated type--truncated--block" bind="Shopify.Inflection.titleize(currentChannelLabel || &quot;&quot;, true)">All channels</div>
                                                         </div>
                                                         <div class="next-grid__cell next-grid__cell--no-flex">
                                                            <svg class="next-icon next-icon--size-20 next-icon--no-nudge ui-channel-selector__icon" role="img" aria-labelledby="next-disclosure-830d6947bcf19a658ee167c332d6694c-title">
                                                               <title id="next-disclosure-830d6947bcf19a658ee167c332d6694c-title">&lt;p&gt;platform.views.admin.ui_helper.channel_selector.select_channel&lt;/p&gt;</title>
                                                               <use xlink:href="#next-disclosure"></use>
                                                            </svg>
                                                         </div>
                                                      </div>
                                                   </button>
                                                   <div class="ui-popover ui-popover--align-edge" data-popover-horizontally-relative-to-closest=".next-card">
                                                      <div class="ui-popover__tooltip"></div>
                                                      <div class="ui-popover__content-wrapper">
                                                         <div class="ui-popover__content">
                                                            <div class="ui-popover__pane">
                                                               <ul class="ui-action-list home-channel-popover">
                                                                  <li class="ui-action-list__item"><button class="ui-action-list-action  ui-action-list-action--selected" bind-class="{'ui-action-list-action--selected': currentChannelId == &quot;all&quot;}" bind-event-click="setChannel(&quot;all&quot;)">All channels</button></li>
                                                                  <li class="ui-action-list__item"><button class="ui-action-list-action " bind-class="{'ui-action-list-action--selected': currentChannelId == &quot;580111&quot;}" bind-event-click="setChannel(&quot;580111&quot;)">Online Store</button></li>
                                                                  <li class="ui-action-list__item"><button class="ui-action-list-action js-other-channel" bind-class="{'ui-action-list-action--selected': currentChannelId == &quot;other&quot;}" bind-event-click="setChannel(&quot;other&quot;)">Other</button></li>
                                                               </ul>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </span>
                                          </span>
                                       </div>
                                       <div class="next-grid__cell">
                                          <div data-define="{datepicker: new Shopify.HomeSidebarDatepicker(
                                             this,
                                             homeSidebar.initialDate)}">
                                             <div class="ui-popover__container ui-popover__container--full-width-container">
                                                <button class="ui-button btn--full-width" type="button" name="button">
                                                   <div class="next-grid next-grid--no-padding next-grid--space-between">
                                                      <div class="next-grid__cell next-grid__cell--no-flex">
                                                         <span bind="datepicker.dateLabel">Today</span>
                                                      </div>
                                                      <div class="next-grid__cell next-grid__cell--no-flex">
                                                         <svg class="next-icon next-icon--size-20 next-icon--no-nudge ui-channel-selector__icon" role="img" aria-labelledby="next-disclosure-96df5f3b410c75daab331a0fd6455336-title">
                                                            <title id="next-disclosure-96df5f3b410c75daab331a0fd6455336-title">Select date range</title>
                                                            <use xlink:href="#next-disclosure"></use>
                                                         </svg>
                                                      </div>
                                                   </div>
                                                </button>
                                                <div class="ui-popover ui-popover--full-height" data-popover-relative-to-closest=".next-card">
                                                   <div class="ui-popover__tooltip"></div>
                                                   <div class="ui-popover__content-wrapper">
                                                      <div class="ui-popover__content">
                                                         <div class="ui-popover__pane">
                                                            <ul class="next-list next-list--compact next-list--home-sidebar">
                                                               <li>
                                                                  <button class="next-list__item next-list__item--is-selected" data-bind-class="{'next-list__item--is-selected': datepicker.selectedDate == &quot;today&quot;}" data-bind-event-click="datepicker.changeDate(&quot;today&quot;)">
                                                                     <div class="next-grid next-grid--no-padding next-grid--space-between">
                                                                        <div class="next-grid__cell">
                                                                           <span>Today</span>
                                                                        </div>
                                                                        <div class="next-grid__cell home-datepicker__quick-date-range">
                                                                           <time data-bind="datepicker.formatted[&quot;today&quot;]" class="type--subdued">Apr 12</time>
                                                                        </div>
                                                                     </div>
                                                                  </button>
                                                               </li>
                                                               <li>
                                                                  <button class="next-list__item" data-bind-class="{'next-list__item--is-selected': datepicker.selectedDate == &quot;yesterday&quot;}" data-bind-event-click="datepicker.changeDate(&quot;yesterday&quot;)">
                                                                     <div class="next-grid next-grid--no-padding next-grid--space-between">
                                                                        <div class="next-grid__cell">
                                                                           <span>Yesterday</span>
                                                                        </div>
                                                                        <div class="next-grid__cell home-datepicker__quick-date-range">
                                                                           <time data-bind="datepicker.formatted[&quot;yesterday&quot;]" class="type--subdued">Apr 11</time>
                                                                        </div>
                                                                     </div>
                                                                  </button>
                                                               </li>
                                                               <li>
                                                                  <button class="next-list__item" data-bind-class="{'next-list__item--is-selected': datepicker.selectedDate == &quot;this_week&quot;}" data-bind-event-click="datepicker.changeDate(&quot;this_week&quot;)">
                                                                     <div class="next-grid next-grid--no-padding next-grid--space-between">
                                                                        <div class="next-grid__cell">
                                                                           <span>This week</span>
                                                                        </div>
                                                                        <div class="next-grid__cell home-datepicker__quick-date-range">
                                                                           <time data-bind="datepicker.formatted[&quot;this_week&quot;]" class="type--subdued">Apr 8–14</time>
                                                                        </div>
                                                                     </div>
                                                                  </button>
                                                               </li>
                                                               <li>
                                                                  <button class="next-list__item" data-bind-class="{'next-list__item--is-selected': datepicker.selectedDate == &quot;this_month&quot;}" data-bind-event-click="datepicker.changeDate(&quot;this_month&quot;)">
                                                                     <div class="next-grid next-grid--no-padding next-grid--space-between">
                                                                        <div class="next-grid__cell">
                                                                           <span>This month</span>
                                                                        </div>
                                                                        <div class="next-grid__cell home-datepicker__quick-date-range">
                                                                           <time data-bind="datepicker.formatted[&quot;this_month&quot;]" class="type--subdued">Apr 1–30</time>
                                                                        </div>
                                                                     </div>
                                                                  </button>
                                                               </li>
                                                            </ul>
                                                            <div class="home-calendar__wrapper" data-define="{calendar: new Shopify.HomeSidebarCalendar(this, datepicker)}">
                                                               <div class="ui-stack ui-stack--alignment-center">
                                                                  <div class="home-calendar__month-nav-button">
                                                                     <button class="ui-button btn--icon btn--plain" data-bind-event-click="calendar.prevMonth()" aria-label="Previous month" type="button" name="button">
                                                                        <svg class="next-icon next-icon--rotate-180 next-icon--size-16">
                                                                           <use xlink:href="#next-chevron"></use>
                                                                        </svg>
                                                                     </button>
                                                                  </div>
                                                                  <div class="ui-stack-item ui-stack-item--fill">
                                                                     <h4 class="next-heading next-heading--small next-heading--no-margin type--centered" data-bind="calendar.monthName">April 2018</h4>
                                                                  </div>
                                                                  <div class="home-calendar__month-nav-button">
                                                                     <button class="ui-button btn--icon btn--plain" data-bind-event-click="calendar.nextMonth()" aria-label="Next month" type="button" name="button">
                                                                        <svg class="next-icon next-icon--size-16">
                                                                           <use xlink:href="#next-chevron"></use>
                                                                        </svg>
                                                                     </button>
                                                                  </div>
                                                               </div>
                                                               <div class="js-home-calendar">
                                                                  <table class="home-calendar">
                                                                     <caption class="is-visuallyhidden">Calendar for the month of April 2018</caption>
                                                                     <tbody>
                                                                        <tr>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Sunday">Sun</abbr>
                                                                           </th>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Monday">Mon</abbr>
                                                                           </th>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Tuesday">Tue</abbr>
                                                                           </th>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Wednesday">Wed</abbr>
                                                                           </th>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Thursday">Thu</abbr>
                                                                           </th>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Friday">Fri</abbr>
                                                                           </th>
                                                                           <th class="home-calendar__heading" scope="col">
                                                                              <abbr title="Saturday">Sat</abbr>
                                                                           </th>
                                                                        </tr>
                                                                        <tr>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">1</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">2</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">3</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">4</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">5</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">6</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">7</button>
                                                                           </td>
                                                                        </tr>
                                                                        <tr>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">8</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">9</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">10</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">11</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              home-calendar__date--range-start
                                                                              home-calendar__date--range-end
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">12</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">13</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">14</button>
                                                                           </td>
                                                                        </tr>
                                                                        <tr>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">15</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">16</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">17</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">18</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">19</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">20</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">21</button>
                                                                           </td>
                                                                        </tr>
                                                                        <tr>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">22</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">23</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">24</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">25</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">26</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">27</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">28</button>
                                                                           </td>
                                                                        </tr>
                                                                        <tr>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">29</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                              <button class="ui-button btn--link btn--full-size" type="button" name="button">30</button>
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                           </td>
                                                                           <td class="home-calendar__date
                                                                              ">
                                                                           </td>
                                                                        </tr>
                                                                     </tbody>
                                                                  </table>
                                                               </div>
                                                            </div>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <section class="next-card next-card--stacked" data-bind-show="homeSidebar.isActive(&quot;all&quot;)">
                                 <section class="next-card__section">
                                    <div class="home-graph__wrapper">
                                       <div class="next-grid next-grid--no-padding">
                                          <div class="next-grid__cell">
                                             <h2 class="next-heading next-heading--quarter-margin next-heading--small">
                                                Total sales
                                             </h2>
                                          </div>
                                          <div class="next-grid__cell">
                                             <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                          </div>
                                       </div>
                                       <div define="{
                                          sales: new Shopify.HomeSalesReport(
                                          this,
                                          {
                                          channelId: &quot;all&quot;,
                                          homeSidebar: homeSidebar
                                          }
                                          )
                                          }" context="sales">
                                          <div class="next-grid next-grid--no-padding next-grid--aligned-to-baseline next-grid--space-between">
                                             <div class="next-grid__cell next-grid__cell--no-flex">
                                                <span class="type--number type--number--large">Rs. 0.00</span>
                                             </div>
                                             <div class="next-grid__cell next-grid__cell--no-flex">
                                                <span class="type--subdued">0 orders</span>
                                             </div>
                                          </div>
                                          <div class="home-graph home-graph--sales">
                                             <div class="home-graph__y-axis" aria-hidden="true">
                                                <small class="home-graph__y-axis-label">
                                                Rs. 5
                                                </small>
                                                <small class="home-graph__y-axis-label">
                                                </small>
                                                <small class="home-graph__y-axis-label">
                                                Rs. 3
                                                </small>
                                                <small class="home-graph__y-axis-label">
                                                </small>
                                                <small class="home-graph__y-axis-label">
                                                Rs. 1
                                                </small>
                                                <small class="home-graph__y-axis-label">
                                                </small>
                                             </div>
                                             <div class="home-graph__bars-and-x-axis">
                                                <div class="home-graph__bars">
                                                   <div class="home-graph__bar-wrapper" style="margin-left: 2px;" aria-label="April 12, 2018 12am Rs. 0.00 ">
                                                      <div class="home-graph__tooltip" style="margin-top: 99px;
                                                         left: 10%;
                                                         transform: translateX(-10%) translateY(-100%);">
                                                         <p>April 12, 2018 12am</p>
                                                         <p>Rs. 0.00</p>
                                                      </div>
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper" style="margin-left: 2px;" aria-label="April 12, 2018 1am Rs. 0.00 ">
                                                      <div class="home-graph__tooltip" style="margin-top: 99px;
                                                         left: 10%;
                                                         transform: translateX(-10%) translateY(-100%);">
                                                         <p>April 12, 2018 1am</p>
                                                         <p>Rs. 0.00</p>
                                                      </div>
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__bar-wrapper home-graph__bar-wrapper--future" style="margin-left: 2px;" aria-hidden="true">
                                                      <div class="home-graph__bar" style="height: 2px;
                                                         margin-top: 99px">
                                                         <div class="home-graph__tooltip-tail"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="home-graph__x-axis home-graph__x-axis--many-data-points" aria-hidden="true">
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick home-graph__x-axis-tick--with-label">
                                                      </div>
                                                      <small class="home-graph__x-axis-label">12am</small>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick home-graph__x-axis-tick--with-label">
                                                      </div>
                                                      <small class="home-graph__x-axis-label">8am</small>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick home-graph__x-axis-tick--with-label">
                                                      </div>
                                                      <small class="home-graph__x-axis-label">4pm</small>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick">
                                                      </div>
                                                   </div>
                                                   <div class="home-graph__x-axis-mark" style="margin-left: 2px;">
                                                      <div class="home-graph__x-axis-tick home-graph__x-axis-tick--with-label">
                                                      </div>
                                                      <small class="home-graph__x-axis-label">11pm</small>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </section>
                               
                               
                                 
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h5 class="next-heading next-heading--small">Top products</h5>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       topProducts: new Shopify.HomeTopProductsReport(
                                       this,
                                       {
                                       channelId: &quot;all&quot;,
                                       channelName: &quot;&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetViewName: &quot;sales&quot;,
                                       widgetErrorMessage: &quot;There were no sales during this time.&quot;
                                       }
                                       )
                                       }" data-context="topProducts">
                                       <p class="home-channel-data-error">There were no sales during this time.</p>
                                    </div>
                                 </section>
                              </section>
                              <section class="next-card next-card--stacked hide" data-bind-show="homeSidebar.isActive(&quot;580111&quot;)">
                                 <section class="next-card__section">
                                    <div class="home-graph__wrapper">
                                       <div class="next-grid next-grid--no-padding">
                                          <div class="next-grid__cell">
                                             <h2 class="next-heading next-heading--quarter-margin next-heading--small">
                                                Total sales
                                             </h2>
                                          </div>
                                          <div class="next-grid__cell">
                                             <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                          </div>
                                       </div>
                                       <div define="{
                                          sales: new Shopify.HomeSalesReport(
                                          this,
                                          {
                                          channelId: &quot;580111&quot;,
                                          homeSidebar: homeSidebar
                                          }
                                          )
                                          }" context="sales">
                                       </div>
                                    </div>
                                 </section>
                                 <section class="next-card__section" data-define="{
                                    breakdown: new Shopify.HomeTotalSalesBreakdown(
                                    this,
                                    {
                                    channelId: &quot;580111&quot;,
                                    homeSidebar: homeSidebar
                                    }
                                    )
                                    }" data-context="breakdown">
                                 </section>
                                 <section class="next-card__section">
                                    <div class="home-graph__wrapper">
                                       <div class="next-grid next-grid--no-padding">
                                          <div class="next-grid__cell">
                                             <h2 class="next-heading next-heading--quarter-margin next-heading--small">Visits</h2>
                                          </div>
                                          <div class="next-grid__cell">
                                             <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                          </div>
                                       </div>
                                       <div data-define="{
                                          visitors: new Shopify.HomeOnlineStoreVisitorsReport(
                                          this,
                                          {
                                          channelId: &quot;580111&quot;,
                                          homeSidebar: homeSidebar
                                          }
                                          )
                                          }" data-context="visitors">
                                       </div>
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h5 class="next-heading next-heading--small">Top products</h5>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       topProducts: new Shopify.HomeTopProductsReport(
                                       this,
                                       {
                                       channelId: &quot;580111&quot;,
                                       channelName: &quot;&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetViewName: &quot;sales&quot;,
                                       widgetErrorMessage: &quot;There were no sales during this time.&quot;
                                       }
                                       )
                                       }" data-context="topProducts">
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h2 class="next-heading next-heading--small">Conversion funnel</h2>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       conversionFunnel: new ((null === true) ? Shopify.HomeConversionReport : Shopify.HomeOnlineStoreConversionReport)(
                                       this,
                                       {
                                       channelId: '580111',
                                       homeSidebar: homeSidebar
                                       }
                                       )
                                       }" data-context="conversionFunnel">
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h2 class="next-heading next-heading--small">Top referrers</h2>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       referrers: new Shopify.HomeTopReferrersReport(
                                       this,
                                       {
                                       channelId: &quot;580111&quot;,
                                       channelName: &quot;Online Store&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetErrorMessage: &quot;There were no referrals during this time.&quot;
                                       }
                                       )
                                       }" data-context="referrers">
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h2 class="next-heading next-heading--small">Top social sources</h2>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       referrers: new Shopify.HomeTopSocialReferrersReport(
                                       this,
                                       {
                                       channelId: &quot;580111&quot;,
                                       channelName: &quot;Online Store&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetErrorMessage: &quot;There were no social referrals during this time.&quot;
                                       }
                                       )
                                       }" data-context="referrers">
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h2 class="next-heading next-heading--small">Top countries</h2>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       referrers: new Shopify.HomeTopCountriesReport(
                                       this,
                                       {
                                       channelId: &quot;580111&quot;,
                                       channelName: &quot;Online Store&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetErrorMessage: &quot;There was no traffic during this time.&quot;
                                       }
                                       )
                                       }" data-context="referrers">
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h2 class="next-heading next-heading--small">Top landing pages</h2>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       referrers: new Shopify.HomeTopLandingPagesReport(
                                       this,
                                       {
                                       channelId: &quot;580111&quot;,
                                       channelName: &quot;Online Store&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetErrorMessage: &quot;There was no traffic during this time.&quot;
                                       }
                                       )
                                       }" data-context="referrers">
                                    </div>
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h2 class="next-heading next-heading--small">Marketing campaigns</h2>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       referrers: new Shopify.HomeMarketingCampaignsReport(
                                       this,
                                       {
                                       channelId: &quot;580111&quot;,
                                       channelName: &quot;Online Store&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetErrorMessage: &quot;There were no referrals from marketing campaigns during this time.&quot;
                                       }
                                       )
                                       }" data-context="referrers">
                                    </div>
                                 </section>
                              </section>
                              <section class="next-card next-card--stacked hide" data-bind-show="homeSidebar.isActive(&quot;other&quot;)">
                                 <section class="next-card__section">
                                    <div class="home-graph__wrapper">
                                       <div class="next-grid next-grid--no-padding">
                                          <div class="next-grid__cell">
                                             <h2 class="next-heading next-heading--quarter-margin next-heading--small">
                                                Total sales
                                             </h2>
                                          </div>
                                          <div class="next-grid__cell">
                                             <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                          </div>
                                       </div>
                                       <div define="{
                                          sales: new Shopify.HomeSalesReport(
                                          this,
                                          {
                                          channelId: &quot;other&quot;,
                                          homeSidebar: homeSidebar
                                          }
                                          )
                                          }" context="sales">
                                       </div>
                                    </div>
                                 </section>
                                 <section class="next-card__section" data-define="{
                                    breakdown: new Shopify.HomeTotalSalesBreakdown(
                                    this,
                                    {
                                    channelId: &quot;other&quot;,
                                    homeSidebar: homeSidebar
                                    }
                                    )
                                    }" data-context="breakdown">
                                 </section>
                                 <section class="next-card__section">
                                    <div class="next-grid next-grid--no-padding">
                                       <div class="next-grid__cell">
                                          <h5 class="next-heading next-heading--small">Top products</h5>
                                       </div>
                                       <div class="next-grid__cell">
                                          <p class="js-date-label type--subdued type--right" data-bind="homeSidebar.formattedDate">Apr 12</p>
                                       </div>
                                    </div>
                                    <div data-define="{
                                       topProducts: new Shopify.HomeTopProductsReport(
                                       this,
                                       {
                                       channelId: &quot;other&quot;,
                                       channelName: &quot;&quot;,
                                       homeSidebar: homeSidebar,
                                       widgetViewName: &quot;sales&quot;,
                                       widgetErrorMessage: &quot;There were no sales during this time.&quot;
                                       }
                                       )
                                       }" data-context="topProducts">
                                    </div>
                                 </section>
                              </section>
                              
                              
                           </div>
                        </div>
                     </div>
                  </div>
               </div>