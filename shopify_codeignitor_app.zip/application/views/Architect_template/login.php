<!DOCTYPE html>
<html lang="en" class="fresh-html">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Architect</title>
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css">

     <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/uptown/css/uptown.css">
     <link rel="stylesheet" media="all" href="<?php echo base_url(); ?>theme_assets/uptown/custom.css">
     <script type="text/javascript" src="<?php echo base_url(); ?>theme_assets/jquery.js"></script>
     <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
     <script type="text/javascript" src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.bundle.min.js"></script>
     
  </head>
  <body id="body-content" class="page fresh-ui">
    <main class="main-pane" role="main">
      <div class="main-container">
        <section class="ui-card">
          <div class="ui-card__section property-card-section">
            <div class="ui-type-container ">
              
            </div>
          </div>
          <div class="ui-card__section main-card-section">
            <div class="ui-type-container" style="padding: 10px">
            <h1 class="ui-title">Log in to Architect</h1>
            <h2 class="ui-heading">Access your Architect Dashboard</h2>
            <form id="login_form" novalidate="novalidate" action="" accept-charset="UTF-8" method="post">
            <div class="next-input-wrapper">
              <label class="next-label" for="account_email">Email address</label>
              <input type="email" autofocus="autofocus" class="next-input" size="30" name="email" id="account_email">
            </div>

            <div class="next-input-wrapper">
              <div class="ui-form__label-wrapper">
                <label class="next-label password_label" for="account_password">Password</label>
                <a class="forgot-password" href="">Forgot password?</a>
              </div>
              <input type="password" class="next-input" size="30" name="password" id="account_password">
            </div>
            <button class="ui-button ui-button--primary ui-button--size-large" type="submit" name="commit">Log in</button>
            <div class="ui-stack ui-stack--wrap">
              <div>
                
                <a id="create-account" href="#">Create an account</a>
              </div>
            </div>
          </form>
        </div>
      </div>
    </section>
  </div>
</main>
</body>
</html>
<script type="text/javascript">
$('#login_form').submit(function(e) {
    e.preventDefault();
    $.ajax({
       type: "POST",
       url: '<?php echo base_url(); ?>Architect/login',
       data: $(this).serialize(),
       dataType:'json',
       success: function(data)
       {
         if(data['code']==200)
         {
            window.location.href='<?php echo base_url(); ?>Architect/Dashboard';
         }
         else
         {

         }
       }
   });
 });
</script>