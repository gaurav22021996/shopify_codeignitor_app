

<?php
//echo '<pre>';
   //print_r($products);
   //exit;
   $product=$products->product;
    ?>
<form method="post" id="productForm">
<div id="body" class="clearfix" data-tg-refresh="body">
   <div class="" id="content">
      <div id="products-index" data-tg-refresh="products-index" class="page products-page has-contextual-help">
         <div class="ui-title-bar-container ui-title-bar-container--full-width">
            <div class="ui-title-bar">
               <div class="ui-title-bar__main-group">
                  <div class="ui-title-bar__heading-group">
                     <span class="ui-title-bar__icon">
                        <svg class="next-icon next-icon--color-slate-lighter next-icon--size-20">
                           <use xlink:href="#next-products"></use>
                        </svg>
                     </span>
                     <h1 class="ui-title-bar__title">Products Details</h1>
                  </div>
               </div>
               <!--<div class="ui-title-bar__actions-group">
                  <div class="ui-title-bar__actions"><a href="/admin/products/new" class="ui-button ui-button--primary ui-title-bar__action" data-bind-event-click="Shopify.AddProductFunnel.clickAddProduct()" data-allow-default="1">Add product</a></div>
                  </div>-->
            </div>
         </div>
           <div style="width: 80%;text-align: left; padding:20px">
          <h4><?php echo $product->title; ?></h4>
          <input type="hidden" name="productid" value="<?php echo $product->id;?>">
          <input type="hidden" name="productName" value="<?php echo $product->title;?>">
         <span>Variants</span>
       </div>
         <div class="ui-layout__item" id="product-outer-variants" data-tg-refresh="product-outer-variants">
            <section class="ui-card">
               
               <table class="table-hover new-variants-table" id="product-inner-variants" data-tg-refresh="product-inner-variants">
                  <thead>
                     <tr>
                        <th class="select">
                           <span>
                              <div class="tooltip tooltip-left-align tooltip-bottom bulk-actions__select-all-tooltip">
                                 <div class="next-input-wrapper bulk-actions__select-all btn--select-all bulk-actions__select-all--is-sticky"  style="left: auto;">
                                  
                                    <input name="bulk-actions__select-all" id="bulk-actions__select-all" value="" class="next-checkbox js-no-dirty bulk-actions__select-all-checkbox" bind-event-click="bulkActionChecked(this)" type="checkbox">
                                    <span class="next-checkbox--styled">
                                       <svg class="next-icon next-icon--size-10 checkmark">
                                          <use xlink:href="#next-checkmark-thick"></use>
                                       </svg>
                                       <svg class="next-icon next-icon--size-10 indeterminate">
                                          <use xlink:href="#next-minus"></use>
                                       </svg>
                                    </span>
                                 </div>
                               
                              </div>
                              
                           </span>
                        </th>
                        <th style="width: 60px;">Image</th>
                        <th class="variants-table__heading--indent-left" id="edit-option-name-1">
                           Title
                        </th>
                        <th class="tc">Inventory</th>
                        <th class="variants-table__heading--indent-right tr">Price</th>
                        <th class="variants-table__heading--indent-left">SKU</th>
                        
                     </tr>
                  </thead>
                  <tbody  class="new-variants-table__row-wrapper variant-row variant-image-section ui-droppable">
                  <?php foreach($product->variants as $singleVariants){?>
                     <tr class="new-variants-table__row variant">
                        <td class="select new-variants-table__cell">
                           <div class="next-input-wrapper">
                              <input name="selectedProduct[]"  value="<?php echo $singleVariants->id; ?>" class="next-checkbox js-no-dirty s-none selectedProduct" type="checkbox">
                              <span class="next-checkbox--styled">
                                 <svg class="next-icon next-icon--size-10 checkmark">
                                    <use xlink:href="#next-checkmark-thick"></use>
                                 </svg>
                              </span>
                           </div>
                        </td>
                        <td class="new-variants-table__cell" id="variant-image-1395199770672" >
                           <div class="new-variants-table__variant-image-wrapper">
                              <div >
                                 <a class="aspect-ratio aspect-ratio--square aspect-ratio--square--40 aspect-ratio--interactive"  href="#">
                                 <img title="163cm" class="aspect-ratio__content" id="image-732361261104" src="<?php if(isset($product->image->src)){ echo $product->image->src;} ?>">
                                 </a>
                              </div>
                           </div>
                        </td>
                        <td class="new-variants-table__cell tc" style="text-align: left;">
                          <?php echo $singleVariants->title; ?>
                          <input type="hidden" name="variantName[]" value="<?php echo $singleVariants->title; ?>">
                        </td>
                         <td class="new-variants-table__cell tc">
                          <?php echo $singleVariants->inventory_quantity; ?>
                        </td>
                        <td class="new-variants-table__cell" style="text-align: right;" >
                        <?php echo $singleVariants->price;?>
                        <input type="hidden" name="price[]" value="<?php echo $singleVariants->price;?>">
                        </td>
                        <td class="new-variants-table__cell">
                        <?php echo $singleVariants->sku;?>
                        </td>
                        
                     </tr>
                     <?php } ?>
                     <tr >
                       <td colspan="6"><button class="ui-button ui-button--primary" onclick="ajaxAddtocart()" type="submit" name="button">Add to cart</button></td>
                     </tr>

                  </tbody>
               </table>
            </section>
          <div style="width: 80%; text-align: left;padding:20px"> <span>Product Description</span>
           </div>
         <section class="ui-card" style="padding: 25px">
           
            <div style="width: 80%;text-align: left; padding:20px">
           <?php echo $product->body_html; ?>
         </div>
         </section>

         </div>
      </div>
   </div>
</div>
</form>

<script type="text/javascript">
   $(document).ready(function(){
    $( "#productForm" ).on('submit',function( e ) {
  e.preventDefault();
   var FormData = $('#productForm').serialize();
    var Url = '<?php echo base_url(); ?>Architect/addToCart';
    $.ajax({
      type : 'POST',
      url : Url,
      data : FormData,
      dataType:"json",
      beforeSend: function(data){
       
        },
      success: function(data){
       if(data['code']==200){
        $('.cart_qty').html('Cart ' + data['cartCount'])

       }
       
      },async: false
    });
});
   
   });
  
  /* $.ajax({
        type:'post',
        url:'store_items.php',
        data:{
          item_src:img_src,
          item_name:name,
          item_price:price
        },
        success:function(response) {
          document.getElementById("total_items").value=response;
        }
      });*/

</script>