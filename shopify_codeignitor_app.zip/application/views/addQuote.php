<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style type="text/css">
    .deviceDetails{
        border: 1px solid #d2d2d2;
        padding: 10px;
        border-radius: 10px;
    }
    .removeDevice{
      float: right;
      margin-right: 10px;
      cursor: pointer;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="row">
    <div class="col-sm-6 col-sm-offset-3">
      <h3 class="text-center">Get Free Quotes</h3>
      <form method="post" action="" enctype="multipart/form-data">
        <div class="form-group">
          <label for="usr">Name:</label>
          <input required="" type="text" name="fullname" class="form-control" id="usr">
        </div>
        <div id="devices">
          <div class="form-group deviceDetails">
            <label>Pictures of device</label>
            <input required="" type="file" class="form-control" name="devices[one][devicePicture][]" multiple />
            <p class="text-danger h5"><b>Show any scratches, dents, cracks, or scuffs</b></p>

            <label>Device IMEI Number:</label>
            <input required="" type="text" name="devices[one][deviceIMEI]" class="form-control">
          </div>
        </div>
        <div class="form-group text-right">
          <button type="button" class="btn btn-xs btn-primary btn-rounded" onclick="addNewDevice()">Add Device</button>
        </div>
        <div class="form-group">
          <label for="phone">Phone Number:</label>
          <input required="" type="text" name="phone" class="form-control" id="phone">
        </div>
        <div class="form-group">
          <label for="email">Email:</label>
          <input required="" type="email" name="email" class="form-control" id="email">
        </div>

        <div class="form-group">
          <input type="submit" name="submit" class="form-control btn btn-md btn-success" />
        </div>
      </form>
    </div>
  </div>
</div>
<script type="text/javascript">
  function addNewDevice()
  {
    var rand= Math.floor((Math.random() * 999) + 999);
    var html = '<div class="form-group deviceDetails">\
                  <span class="removeDevice text-danger"><i class="fa fa-times-circle" aria-hidden="true"></i></span>\
                  <label>Pictures of device</label>\
                  <input required type="file" class="form-control" name="devices['+rand+'][devicePicture][]" multiple />\
                  <p class="text-danger h5"><b>Show any scratches, dents, cracks, or scuffs</b></p>\
                  <label>Device IMEI Number:</label>\
                  <input required type="text" name="devices['+rand+'][deviceIMEI]" class="form-control">\
                </div>';
    $("#devices").append(html);

    $(".removeDevice").click(function(){
      $(this).parent().remove();
    });
  }
</script>
</body>
</html>