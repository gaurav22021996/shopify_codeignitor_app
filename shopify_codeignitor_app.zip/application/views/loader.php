<!doctype html>
<html class="no-js" lang="en">
<head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="apple-touch-icon" href="apple-touch-icon.html">
        <!-- Place favicon.ico in the root directory -->
        <link rel="stylesheet" href="<?php echo base_url();?>theme_assets/css/vendor.css">
        <link rel="stylesheet" href="<?php echo base_url();?>theme_assets/css/app.css">
        <link rel="stylesheet" id="theme-style" href="<?php echo base_url();?>theme_assets/css/app.css">
         <link rel="stylesheet" id="theme-style" href="<?php echo base_url();?>theme_assets/jquery.dataTables.css">
         <link href="<?php echo site_url(); ?>assets/css/seaff.css" type="text/css" rel="stylesheet">
        <script src="https://cdn.shopify.com/s/assets/external/app.js"></script>
        <script type="text/javascript">
            ShopifyApp.init({
                apiKey : '<?php echo $this->config->item('shopify_api_key'); ?>',
                shopOrigin : '<?php echo 'https://'  . $this->session->userdata('shop'); ?>' 
            });

        </script>
        <?php
        $shop =$this->session->userdata('shop');
        $access_token=$this->session->userdata('access_token');
        ?>  
        <script type="text/javascript">
         var shop='<?php echo $shop; ?>';
         var access_token='<?php echo $access_token; ?>';
        </script>
        <script type="text/javascript">
            ShopifyApp.ready(function(){
                ShopifyApp.Bar.initialize({
                buttons: {
                    primary: {
                    label: 'Save',
                    message: 'unicorn_form_submit',
                    loading: true
                    }
                }
                });
            });
    </script>
    <script src="<?php echo base_url();?>theme_assets/jquery.js"></script>
	<style type="text/css">
	
		body {
	    height: 100%;
	    margin: 0;
	    padding: 0;
	    border: 0;
	    background-color: #f4f6f8;
		}
	</style>

    </head>
    <body>
       <div>
       <center><img src="images/loading_cart.gif"></center> 	
       </div>
    </body>
    <script type="text/javascript">
    	$(document).ready(function(){
    		$.ajax(
					{
							type : 'POST',
							url : '<?php echo base_url(); ?>Ajax/LoginCheck',
							data : {access_token:'<?php echo $access_token; ?>'},
							dataType:"json",
						beforeSend: function(data)
						{
							
						},
						success: function(data)
						{
								if(data['code'] == 200)
							{
								window.location.href='<?php echo base_url(); ?>Home/Dashboard?shop=<?php echo $shop; ?>&access_token=<?php echo $access_token;?>';

							}
								else
							{
								window.location.href='<?php echo base_url(); ?>Auth/Install_login';

							}
				
						},
						 error: function () {
						 	window.location.href='<?php echo base_url(); ?>Auth/Install_login';
						 },
						async: false
				
			});


    	});
    </script>
    </html>

