<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function getSessionArchitect()
{
    $ci =& get_instance();
    return  $ci->session->userdata('architectId');

}

function getArchitectDetails($Architectid)
{ 
  $ci =& get_instance();
  $ci->load->model('Global_model');
  return $ci->Global_model->getArchitectAccount_details($Architectid);
}

function getCartCount()
{
  $ci =& get_instance();
  $ci->load->model('Global_model');
  $architectId=getSessionArchitect();
  return $ci->Global_model->getCartitemsQty($architectId);

}
function getCart()
{
  $ci =& get_instance();
  $ci->load->model('Global_model');
  $architectId=getSessionArchitect();
  return $ci->Global_model->getCartitems($architectId);

}







function shopifyData(){
	$ci =& get_instance();
      $data = array(
            'API_KEY' => $ci->config->item('shopify_api_key'),
            'API_SECRET' => $ci->config->item('shopify_secret'),
            'SHOP_DOMAIN' => $ci->session->userdata('shop'),
            'ACCESS_TOKEN' => $ci->session->userdata('access_token')
            );
     return $data;

     }
     
       function getShopDataby_shop($shop)
    {
        $ci =& get_instance();
      $query=$ci->db->query("SELECT * FROM `shopify_stores` where domain='".$shop."' limit  0,1");
      $rowdata=$query->row();
      if(count($rowdata)>0)
      {
          
        return $rowdata;
      }
    }
   function getShop_accessToken()
    {
           $ci =& get_instance();
      $query=$ci->db->query("SELECT * FROM `shopify_stores` limit  0,1");
      $rowdata=$query->row();
      if(count($rowdata)>0)
      {
           $data = array(
            'API_KEY' => $ci->config->item('shopify_api_key'),
            'API_SECRET' => $ci->config->item('shopify_secret'),
            'SHOP_DOMAIN' => $rowdata->domain,
            'ACCESS_TOKEN' => $rowdata->token
            );
     return $data;
      }
    }

    function getShop_accessToken_byShop($shop=NULL)
    {
           $ci =& get_instance();
      $query=$ci->db->query("SELECT * FROM `shopify_stores` where domain='".$shop."' limit  0,1");
      $rowdata=$query->row();
      if(count($rowdata)>0)
      {
           $data = array(
            'API_KEY' => $ci->config->item('shopify_api_key'),
            'API_SECRET' => $ci->config->item('shopify_secret'),
            'SHOP_DOMAIN' => $rowdata->domain,
            'ACCESS_TOKEN' => $rowdata->token
            );
     return $data;
      }
    }

    function session_auth()
    {
         $ci =& get_instance();
       
        $data['shop']=$ci->session->userdata('shop');
        $data['access_token']=$ci->session->userdata('access_token');
     
       if($data['shop']!='' && $data['access_token']!='')
       {  
         return array('shop' =>$data['shop'],'access_token'=>$data['access_token']);
       }else
       {
           redirect('Auth/Install_login');
       }

    

    }
